#!/usr/bin/env nodejs

/*##############################################################################
# ser_pcduino.js
#
# Code for GPIO access server on the pcDuino via Nodejs
#
# 04 Dec 2016 - Abderrahmane Adda Benattia, Leog Laboratory
#
# This code is under MIT licence if you find it useful
# 
#
##############################################################################*/

var http = require("http");
var url=require("url");
var querystring = require('querystring');
var content="vide";

function onRequest(request, response) {
  console.log("La Requête reçue.");
 var params = querystring.parse(url.parse(request.url).query);
  response.writeHead(200, {"Content-Type": "text/html",'Access-Control-Allow-Origin':'*'});
  //response.write("Hello Abderrahmane <br>");
 
  
 
 
if ('v1','v2','v3','v4','v5','v6','v7','v8',
	'v11','v12','v13','v14','v15','v16','v17','v18'  in params) {

    var sys = require('sys')
    var exec = require('child_process').exec;
    function puts(error, stdout, stderr) { sys.puts(stdout) }
	for (i = 0; i < 16; i++) { 
    	exec('echo 1 > /sys/devices/virtual/misc/gpio/mode/gpio'+i);  // pin en mode out '1'
	}
	
	exec('echo '+params['v1'] +' > /sys/devices/virtual/misc/gpio/pin/gpio0');
	exec('echo '+params['v2'] +' > /sys/devices/virtual/misc/gpio/pin/gpio1');
	exec('echo '+params['v3'] +' > /sys/devices/virtual/misc/gpio/pin/gpio2');
	exec('echo '+params['v4'] +' > /sys/devices/virtual/misc/gpio/pin/gpio3');
	exec('echo '+params['v5'] +' > /sys/devices/virtual/misc/gpio/pin/gpio4');
	exec('echo '+params['v6'] +' > /sys/devices/virtual/misc/gpio/pin/gpio5');
	exec('echo '+params['v7'] +' > /sys/devices/virtual/misc/gpio/pin/gpio6');
	exec('echo '+params['v8'] +' > /sys/devices/virtual/misc/gpio/pin/gpio7');
	
	exec('echo '+params['v11'] +' > /sys/devices/virtual/misc/gpio/pin/gpio8');
	exec('echo '+params['v12'] +' > /sys/devices/virtual/misc/gpio/pin/gpio9');
	exec('echo '+params['v13'] +' > /sys/devices/virtual/misc/gpio/pin/gpio10');
	exec('echo '+params['v14'] +' > /sys/devices/virtual/misc/gpio/pin/gpio11');
	exec('echo '+params['v15'] +' > /sys/devices/virtual/misc/gpio/pin/gpio12');
	exec('echo '+params['v16'] +' > /sys/devices/virtual/misc/gpio/pin/gpio13');
	exec('echo '+params['v17'] +' > /sys/devices/virtual/misc/gpio/pin/gpio14');
	exec('echo '+params['v18'] +' > /sys/devices/virtual/misc/gpio/pin/gpio15');
	
	 exec("cat /sys/devices/virtual/misc/gpio/pin/gpio0",function (error, stdout, stderr) { content = stdout; });
	 //return content;
     response.write('gpio0 :' + content);
	}
    else {
        response.write('Le port gpio doit avoir une valeur, non ?');
    }


  response.end();
}

http.createServer(onRequest).listen(8080);
console.log("Démarrage du serveur ... pcDuino ");
