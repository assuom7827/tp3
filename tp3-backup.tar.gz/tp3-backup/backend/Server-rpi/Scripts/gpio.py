#!/usr/bin/python

from time import sleep
import sys

#from gpiozero import LED

import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


#gpio=(23,24,25,12,26,16,20,21,19,6,5,13,2,17,4,3)  #simple face
gpio=(24,23,25,12,20,16,21,26,5,17,4,6,13,3,2,19)    #double face
params=sys.argv[1]

assert (len(params)>=16),"Missing params" 

print "GPIO Vec: "+ str(gpio)
print "Params: "+params

for index,pin in enumerate(gpio):
    #print "index: "+ str(index)
    #print "val: "+ str(pin)
    #print "gpio: "+str(pin) +"="+params[index]

    #sw=LED(pin)
    GPIO.setup(pin, GPIO.OUT)
    if params[index] == '1':
	GPIO.output(pin , GPIO.HIGH)
        #sw.on()
	print "S"+str(index+1) +"="+params[index]
    else:
        #sw.off
	GPIO.output(pin , GPIO.LOW)

#sleep(5)

