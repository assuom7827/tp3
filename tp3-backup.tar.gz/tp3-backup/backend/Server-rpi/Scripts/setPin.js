if (process.argv.length <= 2) {
    console.log("Usage: " + __filename + " SOME_PARAM");
    process.exit(-1);
}

if (process.argv[2]>17) {
    console.log("pin out of range pin 0 to 17 ");
    process.exit(-1);
}

if (process.argv[3]<0 || process.argv[3]>1) {
    console.log("Val out of range (val= '1' or '0' )");
    process.exit(-1);
}


var pin = process.argv[2];
var val = process.argv[3];
 
console.log('pin: ' + pin);
console.log('val: ' + val);

var exec = require('child_process').exec;
exec('echo 1 > /sys/devices/virtual/misc/gpio/mode/gpio'+pin);  // pin en mode out '1'
exec('echo '+val +' > /sys/devices/virtual/misc/gpio/pin/gpio'+pin);

/* var fs = require("fs");
var pat ="C:/Users/HP/Desktop/"+pin; // "/sys/devices/virtual/misc/gpio/mode/pin"+pin

fs.writeFile(pat,val,function (err,data){
	if (err) return console.err(err);
	console.log("done");
	
}); */