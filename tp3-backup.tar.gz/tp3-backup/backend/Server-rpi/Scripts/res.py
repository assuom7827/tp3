#!/usr/bin/python

import RPi.GPIO as GPIO
import spidev
import time
import sys

spi = spidev.SpiDev()   # create spi object
spi.open(0,0) #spi.open(0, int(sys.argv[1]))                    # spi.open(bus, device) open spi port 0, device (CS) 0
spi.max_speed_hz = 100000
spi.cshigh = False
spi.bits_per_word = 8
#spi.loop = True
#spi.threewire = True
#to_send=[0x01,0x02,0x03]
spi.mode = 0b00                 #0b00


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

cs0=14
cs1=15
GPIO.setup(cs0, GPIO.OUT)
GPIO.setup(cs1, GPIO.OUT)


try:

	GPIO.output(cs0 , GPIO.LOW)
	GPIO.output(cs1 , GPIO.HIGH)

        if sys.argv[1]!='undefined':
		R1=int(sys.argv[1])
        	resp = spi.xfer2([0x00, R1])  #0x00 @pot0  R1
        	print "Pot0: " + " " + str(resp[0]) + " " + str(resp[1])
        if sys.argv[2]!='undefined':
		R2=int(sys.argv[2])
		resp = spi.xfer2([0x10, R2])  #0x10 @pot1  R2
        	print "Pot1: " + " " + str(resp[0]) + " " + str(resp[1])

#	time.sleep(1)

	GPIO.output(cs0 , GPIO.HIGH)
	GPIO.output(cs1 , GPIO.LOW)

	if sys.argv[3]!='undefined':
                R3=int(sys.argv[3])
                resp = spi.xfer2([0x00, R3])  #0x00 @pot0  R3
                print "Pot2: " + " " + str(resp[0]) + " " + str(resp[1])
        if sys.argv[4]!='undefined':
                R4=int(sys.argv[4])
                resp = spi.xfer2([0x10, R4])  #0x10 @pot1  R4
                print "Pot3: " + " " + str(resp[0]) + " " + str(resp[1])


#	time.sleep(1)

finally:
#       pass
	spi.close()
	GPIO.output(cs0 , GPIO.HIGH)
        GPIO.output(cs1 , GPIO.HIGH)





