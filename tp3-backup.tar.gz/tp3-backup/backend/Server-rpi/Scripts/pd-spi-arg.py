#!/usr/bin/python

import spidev
import time
import sys

spi = spidev.SpiDev()	# create spi object
spi.open(0,0) #spi.open(0, int(sys.argv[1])) 			# spi.open(bus, device) open spi port 0, device (CS) 0
spi.max_speed_hz = 100000
spi.cshigh = False
spi.bits_per_word = 8
#spi.loop = True
#spi.threewire = True
#to_send=[0x01,0x02,0x03]
spi.mode = 0b00			#0b00
print "argv 1 val :"+sys.argv[1]
print "argv 2 pot :"+sys.argv[2]

if sys.argv[2]=="pot0":
	pot=0
if sys.argv[2]=="pot1":
	pot=16
try:
	n=sys.argv[1] #n=((float(sys.argv[1])-Rw)*128)/5000
	print int(n)
	print pot
#	print "R1= " + str(i*39) + " Ohm - ",
	resp = spi.xfer2([int(pot), int(n)])  #0x00 @pot0
	print "Read: " + str(len(resp)) + " " + str(resp[0]) + " " + str(resp[1])#
	time.sleep(1)

finally:
#	pass
    spi.close()
