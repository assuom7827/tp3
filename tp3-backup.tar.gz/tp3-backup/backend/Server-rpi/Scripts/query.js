//http://localhost:8080/?pins=2017&val=H

var http = require('http');
var url = require('url');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  var params = url.parse(req.url, true).query;
  console.log(params);
  var txt = params.pins + " " + params.val;
  res.end(txt);
  
}).listen(8080);