#include <core.h>
#include <stdio.h>
#include <OneWire.h>
#include <stdlib.h>

OneWire ds(0);                    // OneWire bus on digital pin 0
byte count=0;
byte i;                         // This is for the for loops
boolean present,same;                // device present var
byte data[32];                  // container for the data from device
byte data2[32];

uint8_t adr, len;

void setup() {
  if (argc < 3) { // We expect 2 arguments
    fprintf(stderr, "%s", "Invalid arguments\n");
    exit (1);
  }
  /*
    printf("Argument count:%d\n",argc);
    printf("Argument 1:%s\n",argv[1]);
    printf("Argument 2:%s\n",argv[2]);
  */
  adr = (uint8_t)strtol(argv[1], NULL, 16);
  //printf("adr :%i\n",adr);    // Printout the adr

  if (adr < 0 || adr > 127 ) {    // Test if the addres is valid
    fprintf(stderr, "%s", "Address out of user's memory range\n");
    exit (1);
  }

  len = (uint8_t)strtol(argv[2], NULL, 10);
  //printf("len :%i\n",len);    // Printout the length of data to read

  if (len > 32 ) { // We expect 2 arguments
    fprintf(stderr, "%s", "Can't read more than 32 bytes at once\n");
    exit (1);
  }

  do{
	present = ds.reset();     // OneWire bus reset, returns a 1/TRUE if there's a device present.
	if (present == true) {
		same=true;
		//printf("Reading %s\n",argv[1]);
		ds.write(0xCC, 1);        //skip rom
		ds.write(0xF0, 1);       // Read Memory

		ds.write(adr, 1); //  Adress to read LSB first
		ds.write(0x00, 1);

		//printf("Mem data:");
		//ds.read_bytes(data, len);   // Reading bytes to the container data

		for ( i = 0; i < len; i++) { data[i]=ds.read();  }
		//printf("\n");
//		delay(10);
		ds.reset();
//		delay(10);
		ds.write(0xCC,1);        //skip rom
		ds.write(0xF0,1);       // Read Memory

		ds.write(adr); //  Adress to read LSB first
		ds.write(0x00);
		//ds.read_bytes(data2, len);   // Reading bytes to the container data
		for ( i = 0; i < len; i++) { data2[i]=ds.read();  }


		for ( i = 0; i < len; i++) {
		  if (data[i] != data2[i]) { same=false; //printf("Not same");
			/*
				printf("\nData1:");
			  for ( i = 0; i < len; i++) {
			    printf("%X",data[i]);  }
			     printf("\nData2:");
                          for ( i = 0; i < len; i++) {
                            printf("%X",data2[i]);  }
			ds.reset();
			delay(100);  */
			 break; }
		}
	}
	else {                           // Nothing is connected in the bus
		if (count++ >20) {printf("Reading failled or nothing connected"); exit(0);}
	}
  }while (!same);
  printf("Result:");
  for ( i = 0; i < len; i++) {
    printf("%c",data[i]);  }
    printf("\n");
  exit(0);
}

void loop() {}
