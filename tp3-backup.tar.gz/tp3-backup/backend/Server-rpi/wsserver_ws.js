﻿/*const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', function connection(ws) {
  ws.on('message', function incoming(message) {
    console.log('received: %s', message);
  });

  ws.send('something');
});
*/
 
var WebSocketServer = require('ws').Server
var Gpio = require('onoff').Gpio; // appel de la librairie onoff

var LED1 = new Gpio(24, 'out'); // utiliser la variable LED associer au GPIO 17 et mettre le GPIO 17 en mode sortie 'OUTPUT"
var LED2 = new Gpio(23, 'out');
var LED3 = new Gpio(25, 'out');
var LED4 = new Gpio(12, 'out');
var LED5 = new Gpio(20, 'out');
var LED6 = new Gpio(16, 'out');
var LED7 = new Gpio(21, 'out');
var LED15 = new Gpio(2, 'out');
var LED16 = new Gpio(19, 'out');

//Création d'un variable WebSocketServer qui fait appel à la librairie ws préalablement installéé.

wss = new WebSocketServer({ port: 8080 });
console.log('Démarrage du serveur ws  sur le port 8080 ... ');

//Créer une instance du serveur wss (WebSocketServer) qui écoute sur le port 8080. Le même port est utilisé par le client.
//On peut créer plusieurs serveurs qui écoutent sur des ports différents.

wss.on('connection', function connection(ws,req) {
	      console.log('Un client est connecté sur la machine: '+req.connection.remoteAddress);
          ws.on('message', function incoming(message) {
          console.log('message reçu:  %s', message);
          //ws.send(message);
		  
          var etatsw = message.split(" ");
          console.log('sw1:', etatsw[0], ' sw2:', etatsw[1], ' sw3:', etatsw[2], ' sw4:', etatsw[3], ' sw5:', etatsw[4], ' sw6:', etatsw[5],' sw7:', etatsw[6], ' sw15:', etatsw[7], ' sw16:', etatsw[8]);
		  
		LED1.writeSync(Number(etatsw[0]));
		LED2.writeSync(Number(etatsw[1]));
		LED3.writeSync(Number(etatsw[2]));
		LED4.writeSync(Number(etatsw[3]));
		LED5.writeSync(Number(etatsw[4]));
		LED6.writeSync(Number(etatsw[5]));
		LED7.writeSync(Number(etatsw[6]));
		LED15.writeSync(Number(etatsw[7]));
		LED16.writeSync(Number(etatsw[8]));
           });
		   

});



