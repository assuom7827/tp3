var http = require("http");
var fs = require("fs");

var pot = sw = false;

var rvalues = [11,24,36,50,62,75,88,100,113,127]; // 0.5 - 1 - 1.5 - 2 - 2.5 - 3 - 3.5 - 4 - 4.5 - 5 kOhm

var exp = "0000001000100010";

var sw_options = {hostname: "192.168.10.134", port: 8080, path: "/gpio.py?v="+exp, method: "GET" };
var pot_options = {hostname: "192.168.10.134", port: 8080, path: "/res.py?pot0=127&pot1=127&pot2=127&pot3=127", method: "GET" };


//for (i in rvalues ) { console.log(rvalues[i]);}

var i=0;

var interval2 = setInterval(function(){

pot_options.path="/res.py?pot0="+rvalues[i]+"&pot1=127&pot2=127&pot3=127"

var sw_req = http.request(sw_options, function(res){
    console.log(`Sw Response Started`);

    res.on("data", function(data){
        console.log(`SW Data: ${data}`);
        if (data=="SW Pass") {
            sw=true;
            console.log(sw);
        }
    });

    res.on("end", function(){
        console.log(`SW Response end staus: ${res.statusCode}`);
    });
});

sw_req.on("error", function(err){
    console.log(`Error with Switches Request: ${err.message}`);
});

sw_req.end();

var pot_req = http.request(pot_options, function(res){
    console.log(`PotResponse Started`);

    res.on("data", function(data){
        console.log(`Pot Data: ${data}`);
        if (data=="Pot Pass") {
            pot=true;
            console.log(pot);
        }
    });

    res.on("end", function(){
        console.log(`Pot Response end staus: ${res.statusCode}`);
    });
});

pot_req.on("error", function(err){
    console.log(`Error with Pot Request: ${err.message}`);
});

pot_req.end();

setTimeout(function(){ console.log("TimeOut"); if (sw == false || pot == false) { console.log("setup failed"); process.exit(); /* i--; */ } i++; console.log(i); },400);

var interval = setInterval(function(){
    if( sw == true && pot == true){
        // DMM request
        console.log("request for dmm");
        //read and save response
        clearInterval(interval);
    }
 },100);
if (i>=9){ clearInterval(interval2);}
},2000);
