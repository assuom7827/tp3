var http = require('http');
var fs = require('fs');
var url = require('url');
var querystring = require('querystring');
var child_process = require('child_process');
// Create a server
http.createServer( function (request, response) {
   console.log("Requested URL: "+request.url);
   var pathname = url.parse(request.url).pathname;  // Parse the request containing file name
   if(pathname=='/'){ pathname='/test.htm' }
   if(pathname=="/gpio.py"){
	   console.log('Switch command');
	   var params =  querystring.parse(url.parse(request.url).query);
	   //console.log(params);
		var workerProcess = child_process.exec('python Scripts/gpio.py '+ params.v ,function (error, stdout, stderr) {
			  if (error) {
				 response.writeHead(404, {'Content-Type': 'text/html'}); response.end();
				 console.log(error.stack);
				 console.log('Error code: '+error.code)
				 console.log('Signal received: '+error.signal);
				}
			 else { 
				console.log(stdout); 
				response.writeHead(200, {'Content-Type': 'text/html'}); response.end(); 
				}
			});
   }
   else if(pathname=="/res.py"){
	console.log('Set Degital pot');
	var params =  querystring.parse(url.parse(request.url).query);
	console.log(params);

	// var cs0=15;   //WiPi
	// var cs1=16;

	//child_process.exec('gpio mode '+cs0+' out && gpio write '+cs0+' 0');
	//child_process.exec('gpio mode '+cs1+' out && gpio write '+cs1+' 1');

	//chip0='gpio mode '+cs0+' out && gpio write '+cs0+' 0 && ' + 'gpio mode '+cs1+' out && gpio write '+cs1+' 1 && ';
	//chip1='gpio mode '+cs0+' out && gpio write '+cs0+' 1 && ' + 'gpio mode '+cs1+' out && gpio write '+cs1+' 0 && ';

	var workerProcess = child_process.exec('python Scripts/res.py ' + ' ' +params.pot0+ ' ' + params.pot1 +' '+ params.pot2 + ' ' + params.pot3,function (error, stdout, stderr) {
		if (error) {
			response.writeHead(404, {'Content-Type': 'text/html'}); response.end();
			console.log(error.stack);
			console.log('Error code: '+error.code);
			console.log('Signal received: '+error.signal);
			}
		else { console.log(stdout);
		       response.writeHead(200, {'Content-Type': 'text/html'}); response.end();
			}
		});

/*
	child_process.exec('gpio mode '+cs0+' out && gpio write '+cs0+' 1');
	child_process.exec('gpio mode '+cs1+' out && gpio write '+cs1+' 0');

	 var workerProcess = child_process.exec(chip1+'python Scripts/res.py ' + ' ' +params.pot2+ ' ' + params.pot3 ,function (error, stdout, stderr) {
         console.log(stdout)
         if (error) {
         console.log(error.stack);
         console.log('Error code: '+error.code);
         console.log('Signal received: '+error.signal);
                    }
                });

	setTimeout(function(){
		        child_process.exec('gpio mode '+cs0+' out && gpio write '+cs0+' 1');
        		child_process.exec('gpio mode '+cs1+' out && gpio write '+cs1+' 1');
			},1000);

*/

	}
   // Print the name of the file for which request is made.

   // Read the requested file content from file system
    else if (request.url.match(/.html$/)){
		fs.readFile(request.url.substr(1), function (err, data) {
			if (err) {
				console.log(err);
				response.writeHead(404, {'Content-Type': 'text/html'});
			}
			else {	
				response.writeHead(200, {'Content-Type': 'text/html'});	
				response.write(data.toString());		
			}
			response.end(); });   
    }
	//else { response.writeHead(200, {'Content-Type': 'text/html'}); response.end(); }
}).listen(8080);
// Console will print the message
console.log('Server running on port 8080');
