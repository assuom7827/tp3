<?php
$host = "192.168.10.210";
$port = 5025;
$host_oscillo = "192.168.10.200";

$waveforms=$_GET['msg1'];
$frq=$_GET['fq'];
$amp=$_GET['ap'];
$offset=$_GET['ofset'];
$phase=$_GET['ph'];
$dcsquare=$_GET['dcycle'];
$symmetry=$_GET['rampsym'];
$pulsewidth=$_GET['pulsewidth'];
$edgetime=$_GET['Edtime'];
$bandwidth=$_GET['Bwidth'];
$bit=$_GET['rate'];
$datapr=$_GET['dataprbs'];
$timeprbs=$_GET['timeprbs'];
$an=$_GET['unit'];
$an2=$_GET['unitph'];
$timebase_I=$_GET['timBs'];
$num_points=2404;

switch($waveforms){
    case "sine":$msg="FUNC sin\n source:FREQuency ".$frq."\n SOURce:VOLTage:UNIT ".$an."\n source:volt ".$amp."\n source:volt:offset ".$offset."\n UNIT:angle ".$an2."\n source:phase ".$phase."\n";
                
                break;
    case "square":$msg="FUNC square\n source:FREQuency ".$frq."\n source:volt ".$amp."\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n source:phase ".$phase."\n func:SQUare:DCYCle ".$dcsquare."\n";
                
                break;
    case 'ramp':$msg="FUNC ramp\n source:FREQuency ".$frq."\n source:volt ".$amp."\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n source:phase ".$phase."\n func:ramp:symmetry ".$symmetry."\n";
                
               break;
    case 'pulse':$msg="FUNC pulse\n source:FREQuency ".$frq."\n source:volt ".$amp."\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n source:phase ".$phase."\n func:pulse:DCYCle ".$pulsewidth."\n FUNCtion:PULSe:TRANsition:BOTH ".$edgetime."\n";
                 
                 break;
    case "tri":$msg="FUNC tri\n source:FREQuency ".$frq."\n source:volt ".$amp."\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n source:phase ".$phase."\n";
               
                break;
    case "noise":$msg="FUNC noise\n func:NOISe:BANDwidth ".$bandwidth."\n source:volt ".$amp."\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n";
                 
                 break;
    case "prbs":$msg="FUNC prbs\n func:prbs:Brate ".$bit."\n source:volt ".$amp."\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n func:prbs:data ".$datapr."\n func:PRBS:TRAN ".$timeprbs."\n";
                 
                 break;
    case "dc":$msg="FUNC dc\n SOURce:VOLTage:UNIT ".$an."\n source:volt:offset ".$offset."\n";
               
                break;    
                 }

                         $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Hors service\n");
                         socket_connect($socket,$host, $port) or die("Could not connect to server\n");
                         socket_write($socket , $msg, strlen($msg)) or die("Could not send data to server\n");
        //oscilloscope-----------------
                        $msg_oscillo=":TIMEBASE:SCALE  ".$timebase_I."\n :WAVEFORM:SOURCE chan2\n:WAVeform:POINts ".$num_points."\n:WAVeform:format ascii\n :WAVeform:data?\n output on\n";
                        $socket_oscillo = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Hors service\n");
                         socket_connect($socket_oscillo,$host_oscillo, $port) or die("Could not connect to server\n");
                         socket_write($socket_oscillo , $msg_oscillo, strlen($msg_oscillo)) or die("Could not send data to server\n");
                         $result1 = socket_read ($socket_oscillo ,65536) or die("Could not read server response1\n");
                         socket_close($socket_oscillo);
                         
                         socket_close($socket);
                       echo $result1;
                   
  

?>