<?php
//$host = "192.168.10.42";
//$port = 5025;
$host=$_GET['h'];
$port=$_GET['l'];
$v=$_GET['n'];
$B=$_GET['g'];
$socket  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
socket_connect($socket, $host, $port) or die("Could not connect to server\n");
if($B=="ramp:symmetry" || $B=="SQUare:DCYCle" || $B=="pulse:DCYCle" || $B=="PULS:TRAN:LEADing" || $B=="PULS:TRAN:TRAiling" || $B=="NOISe:BANDwidth" || $B=="prbs:Brate" || $B=="prbs:data" || $B=="PRBS:TRAN" || $B=="PULSe:tran:both") 
$vol1="FUNC:".$B." ".$v."\n";
else $vol1="source:".$B." ".$v."\n";
socket_write($socket , $vol1, strlen($vol1)) or die("Could not send data to server\n");

socket_close($socket);
?>