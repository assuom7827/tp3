<?php
//$host = "192.168.10.42";
//$port = 5025;
$host=$_GET['h'];
$port=$_GET['l'];
$B= $_GET['g'];
$socket  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
socket_connect($socket, $host, $port) or die("Could not connect to server\n");

if($B=="ramp:symmetry" || $B=="SQUare:DCYCle" || $B=="PULSe:WIDTh" || $B=="PULS:TRAN:LEADing" || $B=="PULS:TRAN:TRAiling" || $B=="NOISe:BANDwidth" || $B=="prbs:Brate" || $B=="prbs:data" || $B=="PRBS:TRAN" || $B=="PULS:TRAN" || $B=="PULSe:tran:both") $vol1="func:".$B."?\n";
          
else $vol1="SOURce:".$B."?\n";
          socket_write($socket , $vol1, strlen($vol1)) or die("Could not send data to server\n");
   $result = socket_read ($socket , 1024) or die("Could not read server response\n"); 
$sign=substr($result,-4,1);
socket_close($socket);
//$sign1=substr($result,-16,1);
//$result=substr($result,-15,16);   
if($B=="volt"){$socketUN  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
	           socket_connect($socketUN, $host, $port) or die("Could not connect to server\n");
               $mes="SOURce:VOLTage:UNIT?\n";
			   socket_write($socketUN , $mes, strlen($mes)) or die("Could not send data to server\n");
			   $un = socket_read ($socketUN , 1024) or die("Could not read server response\n");
			   socket_close($socketUN);
			 $result=(float)$result;
			 $R=strpos($un,'RMS',0);
			 $R=(float)$R;
			 $p=strpos($un,'PP',0);
			 $p=(float)$p;
			 $d=strpos($un,'BM',0);
			 $d=(float)$d;
			 if($result<1){$result=$result*1000;
			                $result = number_format($result, 1, '.', ' ');
			             if($R==1) 
						  $un="mVrms";
					     else if($p==1) $un="mVpp";
						 else if($d==1) $un="mdBm";
						   }
			// if($pow==02 && $sign=="-") $result=$result/100;
			 $result = number_format($result, 3, '.', ' ');
			 echo $result." ".$un;
		
			  }
/*else if($B=="phase"){$result=(float)$result;
                     $pow =substr($result,5,6);
	                  $socketUN  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
	                       socket_connect($socketUN, $host, $port) or die("Could not connect to server\n");
                           $mes="UNIT:ANGLe?\n";
			               socket_write($socketUN , $mes, strlen($mes)) or die("Could not send data to server\n");
			               $un = socket_read ($socketUN , 1024) or die("Could not read server response\n");
			               socket_close($socketUN);
			               if($pow==7 || $pow==-7){$result=substr($result,-7,3);
							           $result=$result*100;
									   $un="ns";
						                }
						   else if($pow==6 || $pow==-6){if($pow==6) $result=substr($result,-7,3);
						                                else $result=substr($result,-7,4);
							                            $result = number_format($result, 2, '.', ' ');
														$un="µs";
						                               }
	                       else if($pow==5 || $pow=="E-5" || $pow==-5){if($pow==5) $result=substr($result,-8,4);
							                                           else  $result=substr($result,-8,5);
														                $result=$result*10;
													                	$result = number_format($result, 2, '.', ' ');
													                    $un="µs";
						                                              }
						  else if($result<=0.000999 && $result>0){$result=$result*1000000;
													                	$result = number_format($result, 2, '.', ' ');
													                    $un="µs";
							  
						                             }
												
						  else if($result<=0.00999 && $result>0){$result=$result*1000000;
													                	$result = number_format($result, 1, ',', '.');
													                   $un="ms";
							                       }
						  else if($result<0){$result=$result*1000000;
						                     if(($result<=999 && $result>0) ||($result>=-999 ) )$un="µs";
											 else  $un="ms";
							                  $result = number_format($result, 1, ',', '.');
						                    }
													  
						   else if($un=="DEG") $un="°";
			              //echo $pow;
	                       echo $result.$un;
                     }*/
else if($B=="phase"){$pow =substr($result,17,20);
                     $socketUN  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
	                                     socket_connect($socketUN, $host, $port) or die("Could not connect to server\n");
                                         $mes="UNIT:ANGLe?\n";
			                             socket_write($socketUN , $mes, strlen($mes)) or die("Could not send data to server\n");
			                             $un = socket_read ($socketUN , 1024) or die("Could not read server response\n");
			                             socket_close($socketUN);
										$D=strpos($un,'EG',0);
										$D=(float)$D;
										$s=strpos($un,'EC',0);
										$s=(float)$s;
                     
					 
					 if($pow==0){$result=substr($result,-21,4);
					             $result=(float)$result;
								
								if($D==1){$un="°";
									            $result=number_format($result,3,'.','');
								                }
								else if($s==1){$un="s";
									           // $result=number_format($result,3,'.','');
								                }
								
						         
								 }
						else if($pow==-9){$result=substr($result,-21,3);
							               $result=(float)$result;
										   $un="ns";
						                  }
					           
	                  else if($pow==-8){$result=substr($result,-21,4);
						                $result=(float)$result;
										$result=$result*10;
										$un="ns";
					                    } 
					  else if($pow==-07){$result=substr($result,-21,5);
						                $result=(float)$result;
										$result=$result*100;
										$un="ns";
					                    } 
					  else if($pow==-06){$result=substr($result,-21,6);
						                $result=(float)$result;
										$result = number_format($result, 2, '.', '');
										$un="µs";
					                    }
					  else if($pow==-05){$result=substr($result,-21,7);
						                $result=(float)$result;
										$result=$result*10;
										$result = number_format($result, 2, '.', '');
										$un="µs";
					                    }
					  else if($pow==-04){$result=substr($result,-21,8);
						                $result=(float)$result;
										$result=$result*100;
										$result = number_format($result, 2, '.', '');
										$un="µs";
					                    }
					  else if($pow==-03){$result=substr($result,-21,10);
						                $result=(float)$result;
										$result=$result*1000;
										$result = number_format($result, 2, ',', '.');
										$un="ms";
					                    }
					  else if($pow==-02){$result=substr($result,-21,10);
						                $result=(float)$result;
										$result=$result*10;
										
										$un="ms";
						  
					                     }					
					  else if($pow==-01){$result=substr($result,-21,6);
						                $result=(float)$result;
										$result=$result*100;
										//$result = number_format($result, 2, ',', '.');
										$un="ms";
										
					                    }
					  else if($pow==01){$result=substr($result,-21,5);
						                $result=(float)$result;
										$result=$result*10;
										
										 
										if($D==1){$un="°";
									            $result=number_format($result,3,'.','');
								                }
								else if($s==1){$un="s";
									           
								                }
										
					                    }
					  else if($pow==02){$result=substr($result,-21,6);
						                $result=(float)$result;
										$result=$result*100;
										//$result = number_format($result, 2, ',', '.');
										if($D==1){$un="°";
									            $result=number_format($result,3,'.','');
								                }
								else if($s==1){$un="s";
									           
								                }
										 
					                    }
					  else if($pow==03){$result=substr($result,-21,6);
						                $result=(float)$result;
										//$result=$result*100;
										$result = number_format($result, 2, '.', '');
										$un="ks";
					                    }
					  else if($pow==04){$result=substr($result,-21,7);
						                $result=(float)$result;
										$result=$result*10;
										$result = number_format($result, 2, '.', '');
										$un="ks";
					                    }
					  else if($pow==05){$result=substr($result,-21,8);
						                $result=(float)$result;
										$result=$result*100;
										$result = number_format($result, 2, '.', '');
										$un="ks";
					                    }
					  else if($pow==06){$result=substr($result,-21,10);
						                $result=(float)$result;
										$result=$result*1000;
										$result = number_format($result, 2, ',', '.');
										$un="Ms";
					                    }
                      echo $result.$un;
					  //echo $D." ".$s;
					}					 
else if($B=="volt:offset"){
			               $result=(float)$result;
			               
						  if($result>=1){$h="V";
						                  $result = number_format($result, 3, '.', ' ');
						                }
						   else if($result<1){$result=$result*1000;
							                  $result = number_format($result, 1, '.', ' ');
											  $h="mV";
							                  }
			              echo $result.$h;
	
                     }
else if($B=="FREQuency" || $B=="NOISe:BANDwidth" || $B=="prbs:Brate"){$pow =substr($result,19,20);
	                  $result=(float)$result;
						if($pow<=-04){
							                                              $result=$result*1000000;
                                                                          
																		  $h="µHz";
																		  $result = number_format($result,0, ',', '.');
                                                                         }
						else if($pow<=-01 && $pow>=-03 ){$result=$result*1000000;
						                                       if($B=="prbs:Brate") $h="mbps";
                                                               else  $h="mHz";
																			 
																			   $result = number_format($result,0, ',', '.');
                                                                              }
						else if($pow>=00 && $pow<=02){$result=$result*1000;
						                                 if($B=="prbs:Brate") $h="bps";
                                                                           else    $h="Hz";
																			   $result = number_format($result,3, ',', '.');
                                                                              }
                     
					    else if($pow>02 && $pow<6){ if($B=="prbs:Brate") $h="kbps";
                                                                         else      $h="kHz";
																			   $result = number_format($result,6, ',', '.');
                                                                              }
				         else if($pow>=06){$result=$result/1000;
						                                     if($B=="prbs:Brate") $h="Mbps";
                                                                           else    $h="MHz";
																			   $result = number_format($result,9, ',', '.');
                                                                              }
		                echo $result.$h;
                           }

else if($B=="PULSe:WIDTh"){$pow =substr($result,19,22);										if($pow == -8){$result=substr($result,-22,5);
																								                      $result=(float)$result;
																								                       $result=$result*10;
																							                            $result = number_format($result,1, ',', '.');
																							                           
																										                $h="ns";
																								                        }	
																											
																							else if($pow==-07){$result=substr($result,-22,6);
																								          $result=(float)$result;
																								               $result=$result*100;
																							                   $result = number_format($result,1, '.', '');
																								                $h="ns";
																										 }
																							else if($pow==-06){$result=substr($result,-22,7);
																								          $result=(float)$result;
																								$result=$result*1000;
																							              $result = number_format($result,1, ',', '.');
																										  $h="µs";
																								         }
																							else if($pow==-05){$result=substr($result,-22,8);
																								                      $result=(float)$result;
																								                       $result=$result*10000;
																							                            $result = number_format($result,1, ',', '.');
																										                $h="µs";
																								                        }
																							else if($pow==-4){$result=substr($result,-22,9);
																								                      $result=(float)$result;
																								                       $result=$result*100000;
																							                            $result = number_format($result,1, ',', '.');
																							                           
																										                $h="µs";
																								                        }
																							else if($pow==-3){$result=substr($result,-22,10);
																								                      $result=(float)$result;
																								                       $result=$result*1000;
																							                            $result = number_format($result,4, ',', '.');
																							                           
																										                $h="ms";
																								                        }
																						    else if($pow==-2){$result=substr($result,-22,11);
																								                      $result=(float)$result;
																								                       $result=$result*10000;
																							                            $result = number_format($result,4, ',', '.');
																							                           
																										                $h="ms";
																								                        }						
	                                                                                       else if($pow==-1){$result=substr($result,-22,12);
																								                      $result=(float)$result;
																								                       $result=$result*100000;
																							                            $result = number_format($result,4, ',', '.');
																							                           
																										                $h="ms";
																								                        }	
																						 echo $result.$h;
																						
                                                                                              } 						
						
else if($B=="ramp:symmetry" || $B=="SQUare:DCYCle" ){/*if($B=="pulse:DCYCle"){$pow =substr($result,19,22);
                                                                                             $result=(float)$result;
																							 if(pow==-03){$result=$result*1000000;
																							              $result = number_format($result,1, '.', '');
																								         $h="ns";
																										 }
																							else if(pow==-02){$result=$result*100000;
																							              $result = number_format($result,1, '.', '');
																								         }
																							else if(pow==-01){$result=$result*10000;
																							              $result = number_format($result,1, ',', '.');
																										  $h="µs";
																								         }
																							else if(pow==00 || pow==01){$result=$result*10000;
																							                            $result = number_format($result,1, ',', '.');
																										                $h="µs";
																								                        }
																							else if(pow==02){$result=999.984,0;
																							                           
																										                $h="µs";
																								                        }							
	
                                                                                              } */
                                                                          
                                                                          $result=(float)$result;
                                                                           $h="%";
                                                                           $result = number_format($result, 2, '.', ' ');
																		  
                                                                           echo $result.$h;
																		   
                                                                          }
else if($B=="PULS:TRAN:LEADing" || $B=="PULS:TRAN:TRAiling" || $B=="PRBS:TRAN" || $B=="PULS:TRAN" || $B=="PULSe:tran:both"){$result=(float)$result;
                                                             $pow =substr($result,5,6);
															 if($pow==9){$result=substr($result,-6,3);
                           												 $h="ns";
																		 $result = number_format($result, 1, '.', ' ');
															             }
															 else if($pow==8){$result=substr($result,-6,3);
																              $h="ns";
															                  $result=$result*10;
																			  $result = number_format($result, 1, '.', ' ');
																			  }
															 else if($pow==-8){$result=substr($result,-7,4);
																               $h="ns";
															                   $result=$result*10;
																			   $result = number_format($result, 1, '.', ' ');
															                   }
															else if($pow==7){$result=substr($result,-6,3);
																             $h="ns";
															                 $result=$result*100;
																			 $result = number_format($result, 1, '.', ' ');
																            }
															else if($pow==-7){$result=substr($result,-7,4);
																              $h="ns";
															                  $result=$result*100;
																			  $result = number_format($result, 1, '.', ' ');
																             }
															else if($pow=="E-7"){$result=substr($result,-8,5);
																                 $h="ns";
															                     $result=$result*100;
																			     $result = number_format($result, 1, '.', ' ');
																                }
															else if($pow==6){$result=substr($result,-6,3);
																             $h="µs";
															                 $result=$result*1000;
																			 $result = number_format($result, 1, ',', '.');
																             }
																echo $result.$h;			 
	
                                                             }
else if($B=="prbs:data") echo $result; 


?>