<?php
//$host = "192.168.10.42";
//$port = 5025;
$host=$_GET['h'];
$port=$_GET['l'];

$socket  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
$fms1=$_GET['g'];
socket_connect($socket, $host, $port) or die("Could not connect to server\n");
$vol1="FUNC ".$fms1."\n";
socket_write($socket , $vol1, strlen($vol1)) or die("Could not send data to server\n");
socket_close($socket);
?>