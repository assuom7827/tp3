<?php
$host = "192.168.100.114";
$port = 5025;
$msg=$_GET['msg1'];
$socket  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Hors service\n");
socket_connect($socket, $host, $port) or die("Could not connect to server\n");
socket_write($socket , $msg, strlen($msg)) or die("Could not send data to server\n");
$result1 = socket_read ($socket ,65536) or die("Could not read server response1\n");
socket_close($socket);
echo $result1;
?>

