<?php
//$host = "192.168.10.42";
//$port = 5025;
$host=$_GET['h'];
$port=$_GET['l'];
$an=$_GET['g'];
$socket  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
socket_connect($socket, $host, $port) or die("Could not connect to server\n");
//$vol1="UNIT:ANGLe?\n";
                     
          $vol1="UNIT:angle ".$an."\n";
          socket_write($socket , $vol1, strlen($vol1)) or die("Could not send data to server\n");
        


$result = socket_read ($socket , 1024) or die("Could not read server response\n");
socket_close($socket);
//$result=(float)$result;

//$result = number_format($result, 3, '.', ' ');
//echo $result ;