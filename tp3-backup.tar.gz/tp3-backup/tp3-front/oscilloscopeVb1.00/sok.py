from flask import Flask, render_template, request, jsonify
import socket
#app = Flask(__name__)
app = Flask(__name__, static_url_path='/static')
@app.route('/')

def index():
    return render_template('index.html')

@app.route('/_get_data')
def get_data():
    param = request.args.get('param', 'pas de param', type=str)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('192.168.100.114', 5025))
    s.sendall(param)
    data = s.recv(16348)
    print (data)
    s.close()
   # print 'Received', repr(data)
    return jsonify(result=data)

if __name__ == '__main__':
    app.run(
        host="0.0.0.0",
        port=int("8093"),
        debug=True
    )

