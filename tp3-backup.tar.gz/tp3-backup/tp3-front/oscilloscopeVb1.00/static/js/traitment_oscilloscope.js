var deltxIncr,
             num_points=120,
             timebase=0.001,
             timebase_I=0.001,
             timebaseMin,
             scale_x,
             scale_y,
             svg,
             lineGen,
             data,
             datagrid,
             div_Y=0.02,
             max_Y=div_Y*4,
             min_Y=-max_Y,
             incr_offset_curs,
             timebaseScale=timebase*5,
             timebaseMinScale=-timebaseScale,
             scaledatamax=timebase*5,
             scaledatamin=-scaledatamax,
             indexTime=0,
             operation="offset",
             indexAmp1=5,
             indexAmp2=5,
             indexAmp3=5,
             indexAmp4=5,
             curs="x2",
             ch=1,
             dat1,
             dat2,
             dat3,
             dat4,
             dat_curs_x1,
             dat_curs_x2,
             dat_curs_y1,
             dat_curs_y2,
             curs_x1,
             curs_x2,
             curs_y1,
             curs_y2,
             division_par,
             channel1=false,
             channel2=false,
             channel3=false,
             channel4=false,
             cursors=false,
             move_curs=false,
             scale_min_ch1=-0.08,
             scale_max_ch1=0.08,
             scale_min_ch2=-0.08,
             scale_max_ch2=0.08,
             scale_min_ch3=-0.08,
             scale_max_ch3=0.08,
             scale_min_ch4=-0.08,
             scale_max_ch4=0.08,
             offset1=0,
             offset2=0,
             offset3=0,
             offset4=0,
             valueAmplitude=[20,8,4,2,0.8,0.4,0.2,0.08,0.04,0.02,0.008,0.004],
             valueOffsetAmp=[0,0,0,0,0,0,2,2.5,2,2,2.5,2],
             valueTimeBase=[0.001,0.0005,0.0002,0.0001,0.00005,0.00002,0.00001],
             frq,
             type_setting='fine',
             scale_curs=max_Y,
             dataip,
             data1=[],
             data2=[],
             r1,
             r2,
             test=false;
 $(function()
            {
               
                $('#plus').click(function(){switch(operation){
                                                              case "T_B":TimeBase('positive',data);
                                                                          break;
                                                              case "amp":Amplitude('positive',data);
                                                                          break;
                                                              case "offset":Offsetgraph('positive',data);
                                                                          break;
                                                             }
                });
                                          
                 $('#moins').click(function(){switch(operation){
                                                                case "T_B":TimeBase('negative',data);
                                                                          break;
                                                                case "amp":Amplitude('negative',data);
                                                                          break;
                                                                case "offset":Offsetgraph('negative',data
                                                                                         );
                                                                          break;
                                                             }
                                           });
                
                $('#cur_plus').click(function(){line_curs("positive");
                                                });
                $('#cur_moins').click(function(){line_curs("negative");
                                                });
            
            
          //---------switch TimeBase OFFSET Amplutide -----------------------------//
                    $(".switch").click(function(e) {var Offset = $(this).offset();
                                                    var OffsY = e.pageY - Offset.top;
                                                    if (OffsY < 20) {operation="T_B";
                                                                      $(".switch_plug").css("top", "1px");
                                                                     } 
                                                    else {if (OffsY > 40) {operation="amp";
                                                                           $(".switch_plug").css("top", "39px");
                                                                           } 
                                                          else {operation="offset";
                                                                   $(".switch_plug").css("top", "20px");
                                                                }
                                                           }
                                                      });
         //-----------------switch cursors x1 x2 y1 y2-----------------//
                    $(".switch_curs").click(function(e) {var Offset = $(this).offset();
                                                         var OffsY = e.pageY - Offset.top;
                                                         if (OffsY <= 17) {curs="x1";
                                                                           $(".switch_plug_curs").css("top", "0px");
                                                                           } 
                                                         else if (OffsY >= 18 && OffsY <= 36){curs="x2";
                                                                                              $(".switch_plug_curs").css("top", "20px");
                                                                                              } 
                                                         else if (OffsY >= 37 && OffsY <= 57) {curs="y1";
                                                                                               $(".switch_plug_curs").css("top", "40px");
                                                                                               }
                                                         else {curs="y2";
                                                               $(".switch_plug_curs").css("top", "60px");
                                                               }   
                                                          });
        //--------------------switch ch source-----------//
                $(".switch_ch").click(function(e) {var Offset = $(this).offset();
                                                         var OffsY = e.pageY - Offset.top;
                                                         if (OffsY <= 32) {ch=1;
                                                                           $(".switch_plug_ch").css("top", "5px");
                                                                     } 
                                                         else if (OffsY >= 33 && OffsY <= 57){ch=2;
                                                                                              $(".switch_plug_ch").css("top", "35px");
                                                                                              } 
                                                         else if (OffsY >= 58 && OffsY <= 88) {ch=3;
                                                                                               $(".switch_plug_ch").css("top", "65px");
                                                                                               }
                                                         else {ch=4;
                                                               $(".switch_plug_ch").css("top", "95px");
                                                               }   
                                                     });
     //----------------------switch setting-------//
              $(".switch_reglage").click(function(e) {var Offset = $(this).offset();
                                                         var OffsetX = e.pageX - Offset.left;
                                                         if (OffsetX <= 40) {type_setting='fine';
                                                                           $(".switch_plug_reglage").css("left", "5px");
                                                                     } 
                                                         
                                                         else {type_setting='normale';
                                                               $(".switch_plug_reglage").css("left", "65px");
                                                               }   
                                                     });
                
                //-----------------------channel------------------------//
                $("#CH1").click(function(e) {if(channel1==false){
                                             $msg=":WGEN:OUTPut ON\n :WGEN:FREQuency 1000\n :WAVeform:POINts:MODE max\n :TIMEBASE:SCALE  "+timebase_I+"\n :WAVEFORM:SOURCE chan1\n:WAVeform:POINts "+num_points+"\n:WAVeform:format ascii\n :WAVeform:data?\n"
                                             $("#CHL1").css("background-color", "cdc727");
                                              getdatascpi_ajax('datach1');
                                                          channel1=true;       
                                                                 }
                                             else{$("#CHL1").css("background-color", "#ddd");
                                                  channel1=false;
                                                  draw_graph();
                                                  }
                                                });
              $("#CH2").click(function(e) {if(channel2==false){
                                             $msg=":TIMEBASE:SCALE  "+timebase_I+"\n :WAVEFORM:SOURCE chan2\n:WAVeform:POINts "+num_points+"\n:WAVeform:format ascii\n :WAVeform:data?\n"
                                             $("#CHL2").css("background-color", "green");
                                              getdatascpi_ajax('datach2');
                                                          channel2=true;       
                                                                 }
                                             else{$("#CHL2").css("background-color", "#ddd");
                                                  channel2=false;
                                                  draw_graph();
                                                  }
                                                });
                $("#CH3").click(function(e) {if(channel3==false){
                                             $msg=":TIMEBASE:SCALE  "+timebase_I+"\n :WAVEFORM:SOURCE chan3\n:WAVeform:POINts "+num_points+"\n:WAVeform:format ascii\n :WAVeform:data?\n"
                                             $("#CHL3").css("background-color", "blue");
                                              getdatascpi_ajax('datach3');
                                                          channel3=true;       
                                                                 }
                                             else{$("#CHL3").css("background-color", "#ddd");
                                                  channel3=false;
                                                  draw_graph();
                                                  }
                                                });
                $("#CH4").click(function(e) {if(channel4==false){
                                             $msg=":TIMEBASE:SCALE  "+timebase_I+"\n :WAVEFORM:SOURCE chan4\n:WAVeform:POINts "+num_points+"\n:WAVeform:format ascii\n :WAVeform:data?\n"
                                             $("#CHL4").css("background-color", "red");
                                              getdatascpi_ajax('datach4');
                                                          channel4=true;       
                                                                 }
                                             else{$("#CHL4").css("background-color", "#ddd");
                                                  channel4=false;
                                                  draw_graph();
                                                  }
                                                });
                /*------Cursors--------------------------------------------*/
                $('#cursors').click(function(e) {
                                                 if(cursors==false ){
                                                 if(curs_x1==undefined)
                                                 cursorsline()
                                                 cursors=true;
                                                 }
                                                 else  cursors=false;
                                                 draw_graph();
                                                 });
            //-----------------------------------------------------------------//
            });
           
            
            //---------------get  data----------------------//
            function getdatascpi_ajax(x){
                                        var sig=$('#mySelect').val();
                                         console.log(sig);
                                         frq=$("#frq").val();
                                         var amp=$("#amp").val();
                                         
                                         if(x=='datach1'){
                                             channel1=true;
                                             test=false;
                                         $msg=":WGEN:OUTPut ON\n :WGEN:FREQuency "+frq+"\n :WGEN:VOLTage "+amp+"\n:WGEN:FUNCtion "+sig+"\n:WAVeform:POINts:MODE max\n :TIMEBASE:SCALE  "+timebase_I+"\n :WAVEFORM:SOURCE chan1\n:WAVeform:POINts "+num_points+"\n:WAVeform:format ascii\n :WAVeform:data?\n";
                                             
                                         }
                                             else {$msg=":WGEN:FREQuency "+frq+"\n :WGEN:VOLTage "+amp+"\n :WGEN:FUNCtion "+sig+"\n :WAVeform:POINts:MODE max\n :TIMEBASE:SCALE  "+timebase_I+"\n :WAVEFORM:SOURCE chan2\n:WAVeform:POINts "+num_points+"\n:WAVeform:format ascii\n :WAVeform:data?\n";
                                                   channel2=true;
                                                   test=true;
                                                  }
                                        /* $.getJSON('/_get_data', { param: $msg 
                                                                 },*/
                                         $.ajax({type:"GET",
                                                 url:"./php/scpi.php",
                                                 data:{msg1: $msg},
                                                 cache:false, 
                                                 success:function(data) {var point_Y=data,point_X;
                                                                           dataip={"datach1":[],"datach2":[],"datach3":[],"datach4":[]};          
                                                                                    var firstpos=10;
                                                                                    deltX();
                                                                                    point_X=timebase_I*(-5);
                                                                                    for(i=0;i<119;i++){var L=point_Y.length;
                                                                                                       
                                                                                                       var pos=point_Y.indexOf(',');
                                                                                                       var Y_point;
                                                                                                       if(pos==-1) Y_point=point_Y.substring(firstpos,13);
                                                                                                       else
                                                                                                       Y_point=point_Y.substring(firstpos, pos);
                                                                                                       //Y_point=parseFloat(Y_point);
                                                                                                       
                                                                                                       if(i>0)
                                                                                                       point_X=point_X+deltxIncr;
                                                                                                       point_X=parseFloat(point_X);
                                                                                                       switch(x){case 'datach1': dataip.datach1.push({"axey":Y_point,"axex":point_X});
                                                                                                                 break;
                                                                                                                 case 'datach2':
                                                                                                       dataip.datach2.push({"axey":Y_point,"axex":point_X});
                                                                                                                 break;
                                                                                                                 case 'datach3':
                                                                                                       dataip.datach3.push({"axey":Y_point,"axex":point_X});
                                                                                                                 break;
                                                                                                                 case 'datach4':
                                                                                                       dataip.datach4.push({"axey":Y_point,"axex":point_X});
                                                                                                                 break;
                                                                                                                 }
                                                                                                      
                                                                                                       point_Y=point_Y.substring(pos+1,L);
                                                                                                       firstpos=0;
                                                                              
                                                                                                      }
                                                                                  //  scaledatamax=point_X;
                                                            /*-----------------------------------------------------*/               
                                                                                    
                                                                                 var data =dataip[x];
                                                                                    
                                                                                    data.forEach(function(d) {
                                                                                                              d.axex = +d.axex;
                                                                                                              d.axey = +d.axey;
                                                                                        
                                                                                                              });
                                                                                    if(x=='datach1') data1=data;
                                                                                    else if(x=='datach2') data2=data;
                                                                                    else if(x=='datach3') data3=data;
                                                                                    else data4=data;
                                                                                    draw_graph();
                                                                                    console.log(data1);
                                                                                    }
                                                });
                                         
                
                                        }
            
            
            
           function deltX(){deltxIncr=timebase_I/((num_points)/10);
                             }
           function draw_graph(){changepot();
                                        
                                         d3.select("#zonegraph").remove();
                                         svg=d3.select('#graph').append('svg').attr("width",638)
                                                                              .attr("height",430)
                                                                              .attr("id", "zonegraph");
                                        
                                         
                                         
                                         if(channel1==true){scale_line("data",scale_min_ch1,scale_max_ch1);
                                                            svg.append('svg:path').data([data1])
                                                                                  .attr("d", lineGen)
                                                                                  .attr('stroke', 'yellow')
                                                                                  .attr('stroke-width',3)
                                                                                  .attr('fill', 'none');
                                                          if(test==false)
                                                              getdatascpi_ajax('datach2');
                                                            }
                                         if(channel2==true){scale_line("data",scale_min_ch2,scale_max_ch2);
                                                            svg.append('svg:path').data([data2])
                                                                                  .attr("d", lineGen)
                                                                                  .attr('stroke', 'green')
                                                                                  .attr('stroke-width', 3)
                                                                                  .attr('fill', 'none');
                                                          }
                                         if(channel3==true){scale_line("data",scale_min_ch3,scale_max_ch3);         
                                                            svg.append('svg:path').data([data3])
                                                                                  .attr("d", lineGen)
                                                                                  .attr('stroke', 'blue')
                                                                                  .attr('stroke-width', 3)
                                                                                  .attr('fill', 'none');
                                                             }
                                         if(channel4==true){scale_line("data",scale_min_ch4,scale_max_ch4);
                                                            svg.append('svg:path').data([data4])
                                                                                  .attr("d", lineGen)
                                                                                  .attr('stroke', 'red')
                                                                                  .attr('stroke-width', 3)
                                                                                  .attr('fill', 'none');
                                                           }
                                         if(cursors==true){
                                                           switch(ch){case 1:scale_line("data",scale_min_ch1,scale_max_ch1);
                                                                             break;
                                                                      case 2:scale_line("data",scale_min_ch2,scale_max_ch2);
                                                                             break;
                                                                      case 3:scale_line("data",scale_min_ch3,scale_max_ch3);
                                                                             break;
                                                                      case 4:scale_line("data",scale_min_ch4,scale_max_ch4);
                                                                             break;
                                                                      }
                                                           svg.append('svg:path').style("stroke-dasharray", ("3, 3"))
                                                                                 .data([dat_curs_x1])
                                                                                 .attr("d", lineGen)
                                                                                 .attr('stroke', 'orange')
                                                                                 .attr('stroke-width', 1)
                                                                                 .attr('fill', 'none');
                                                            svg.append('svg:path').style("stroke-dasharray", ("3, 3"))
                                                                                 .data([dat_curs_x2])
                                                                                 .attr("d", lineGen)
                                                                                 .attr('stroke', 'orange')
                                                                                 .attr('stroke-width', 1)
                                                                                 .attr('fill', 'none');
                                                           svg.append('svg:path').style("stroke-dasharray", ("3, 3"))
                                                                                 .data([dat_curs_y1])
                                                                                 .attr("d", lineGen)
                                                                                 .attr('stroke', 'orange')
                                                                                 .attr('stroke-width', 1)
                                                                                 .attr('fill', 'none');
                                                           svg.append('svg:path').style("stroke-dasharray", ("3, 3"))
                                                                                 .data([dat_curs_y2])
                                                                                 .attr("d", lineGen)
                                                                                 .attr('stroke', 'orange')
                                                                                 .attr('stroke-width', 1)
                                                                                 .attr('fill', 'none');
                                                           }
                                            
                                        /---------------grid Y--------------------/
                                        var gridX=new Array(2); 
                                            gridX[0]=-timebaseScale;
                                        var gridY=new Array(2);
                                         for(i=0;i<9;i++){if(i==4) gridX[0]=0;
                                                          else
                                                          gridX[0]=gridX[0]+timebase;
                                                          gridX[1]=gridX[0];
                                                          // var gridY=new Array(2); 
                                                          gridY[0]=max_Y;
                                                          gridY[1]=min_Y;
                                                          var dataGrid = d3.zip(gridX,gridY);
                                                          
                                                          scale_line("grid",min_Y,max_Y);   
                                                          svg.append('svg:path')
                                                             .attr('d', lineGen(dataGrid))
                                                             .attr('stroke', 'gainsboro')
                                                             .attr('stroke-width',0.5)
                                                             .attr('fill', 'none');
                                                          }
                                         
                                         /---------------grid X--------------------/
                                         gridX[0]=min_Y;
                                         for(i=0;i<7;i++){ 
                                                          gridX[0]=timebaseMinScale;
                                                          gridX[1]=timebaseScale;
                                                          gridY[0]=gridY[0]-(max_Y/4);
                                                          gridY[1]=gridY[0];
                                                          var dataGridY = d3.zip(gridX,gridY);
                                                          scale_line("grid",min_Y,max_Y);   
                                                          svg.append('svg:path')
                                                          .attr('d', lineGen(dataGridY))
                                                          .attr('stroke', 'gainsboro')
                                                          .attr('stroke-width', 0.5)
                                                          .attr('fill', 'none');
                                                          }
                                        }
            function scale_line(x,minY,maxY){scale_x=d3.scale.linear().domain([scaledatamin, scaledatamax]).range([0, 638]);
                                             scale_y=d3.scale.linear().domain([maxY,minY]).range([0,430]);
                                             switch (x){case "data":lineGen = d3.svg.line().x(function(d) {  
                                                                                                           return scale_x(d.axex);
                                                                                                           })
                                                                                           .y(function(d) {
                                                                                                           return scale_y(d.axey);
                                                                                                           })
                                                                                           .interpolate("basis");
                                                                    break;
                                                        case "grid":lineGen = d3.svg.line().x(function(d,i) {  
                                                                                                             return scale_x(d[0]);
                                                                                                            })
                                                                                           .y(function(d,i) {
                                                                                                             return scale_y(d[1]);
                                                                                                             })
                                                                                           .interpolate("basis");
                                                                    break;
                                                        }
                                            } 
            /*---------------------Time Base---------------------*/
            function TimeBase(x,dat){if(x=='positive' && indexTime<6) ++indexTime; 
                                     else if(x=='negative' && indexTime>0) --indexTime;
                                     
                                     timebase=valueTimeBase[indexTime];
                                     scaledatamax=valueTimeBase[indexTime]*5;
                                     timebaseScale=scaledatamax;
                                     scaledatamin=-scaledatamax;
                                     timebaseMinScale=scaledatamin;
                                     var show_TB;
                                     switch(indexTime){case 0:show_TB=valueTimeBase[indexTime]*1000;
                                                              show_TB=show_TB.toFixed(3);
                                                              $(".timebase").val(show_TB+"ms");
                                                              break;
                                                       case 1:show_TB=valueTimeBase[indexTime]*1000000;
                                                              show_TB=show_TB.toFixed(1);
                                                              $(".timebase").val(show_TB+"µs");
                                                              break;
                                                       case 2:show_TB=valueTimeBase[indexTime]*1000000;
                                                              show_TB=show_TB.toFixed(1);
                                                              $(".timebase").val(show_TB+"µs");
                                                              break;
                                                       case 3:show_TB=valueTimeBase[indexTime]*1000000;
                                                              show_TB=show_TB.toFixed(1);
                                                              $(".timebase").val(show_TB+"µs");
                                                              break;
                                                       case 4:show_TB=valueTimeBase[indexTime]*1000000;
                                                              show_TB=show_TB.toFixed(2);
                                                              $(".timebase").val(show_TB+"µs");
                                                              break;
                                                       case 5:show_TB=valueTimeBase[indexTime]*1000000;
                                                              show_TB=show_TB.toFixed(2);
                                                              $(".timebase").val(show_TB+"µs");
                                                              break;
                                                       case 6:show_TB=valueTimeBase[indexTime]*1000000;
                                                              show_TB=show_TB.toFixed(2);
                                                              $(".timebase").val(show_TB+"µs");
                                                              break;
                                                    }
                                     cursorsline();
                                     draw_graph();
                                     }
            /*---------------------Amplitude---------------------*/
            function Amplitude(x,dat){var ampl;
                                      switch(ch){case 1:if(x=='positive' && indexAmp1<valueAmplitude.length-1){++indexAmp1;
                                                                                                             
                                                                                         offset1=offset1*valueOffsetAmp[indexAmp1];
                                                                                 console.log(valueAmplitude[indexAmp1]+"////"+offset1);
                                                                                         scale_max_ch1=valueAmplitude[indexAmp1]+offset1;
                                                                                         scale_min_ch1=-valueAmplitude[indexAmp1]+offset1;
                                                                                         }
                                                        else if(x=='negative' && indexAmp1>0){--indexAmp1;
                                                                                              offset1=offset1*valueOffsetAmp[indexAmp1+1];
                                                                                              scale_max_ch1=valueAmplitude[indexAmp1]+offset1;
                                                                                              scale_min_ch1=-valueAmplitude[indexAmp1]+offset1; 
                                                                                              }
                                                        if(indexAmp1>2){
                                                                        ampl=(valueAmplitude[indexAmp1]/4)*1000;
                                                                        $("#l1").val(ampl+"mV");
                                                                       }
                                                        else {
                                                              ampl=valueAmplitude[indexAmp1]/4;
                                                              $("#l1").val(ampl+"V");
                                                              }
                                                        scale_curs=scale_max_ch1;
                                                        break;
                                                 case 2:if(x=='positive' && indexAmp2<valueAmplitude.length-1){++indexAmp2; 
                                                                                         offset2=offset2*valueOffsetAmp[indexAmp2];
                                                                                         scale_max_ch2=valueAmplitude[indexAmp2]+offset2;
                                                                                         scale_min_ch2=-valueAmplitude[indexAmp2]+offset2;
                                                                                         }
                                                        else if(x=='negative' && indexAmp2>0){--indexAmp2;
                                                                                              offset2=offset2*valueOffsetAmp[indexAmp2+1];
                                                                                              scale_max_ch2=valueAmplitude[indexAmp2]+offset2;
                                                                                              scale_min_ch2=-valueAmplitude[indexAmp2]+offset2; 
                                                                                              }
                                                         
                                                        if(indexAmp2>2){
                                                            ampl=(valueAmplitude[indexAmp2]/4)*1000;
                                                             $("#l2").val(ampl+"mV");
                                                        }
                                                        else {
                                                               ampl=valueAmplitude[indexAmp2]/4;
                                                            $("#l2").val(ampl+"V");
                                                        }
                                                         scale_curs=scale_max_ch2;
                                                         break;
                                                 case 3:if(x=='positive' && indexAmp3valueAmplitude.length-1){++indexAmp3; 
                                                                                         offset3=offset3*valueOffsetAmp[indexAmp3];
                                                                                         scale_max_ch3=valueAmplitude[indexAmp3]+offset3;
                                                                                         scale_min_ch3=-valueAmplitude[indexAmp3]+offset3;
                                                                                         }
                                                        else if(x=='negative' && indexAmp3>0){--indexAmp3;
                                                                                              offset3=offset3*valueOffsetAmp[indexAmp3+1];
                                                                                              scale_max_ch3=valueAmplitude[indexAmp3]+offset3;
                                                                                              scale_min_ch3=-valueAmplitude[indexAmp3]+offset3; 
                                                                                              }
                                                        if(indexAmp3>2){    
                                                            ampl=(valueAmplitude[indexAmp3]/4)*1000;
                                                            $("#l3").val(ampl+"mV"); 
                                                        }
                                                        else{ampl=valueAmplitude[indexAmp3]/4;
                                                             $("#l4").val(ampl+"V");
                                                        }
                                                         scale_curs=scale_max_ch3;
                                                            break;
                                                 case 4:if(x=='positive' && indexAmp4<valueAmplitude.length-1){++indexAmp4; 
                                                                                         offset4=offset4*valueOffsetAmp[indexAmp4];
                                                                                         scale_max_ch4=valueAmplitude[indexAmp4]+offset4;
                                                                                         scale_min_ch4=-valueAmplitude[indexAmp4]+offset4;
                                                                                        }
                                                        else if(x=='negative' && indexAmp4>0){--indexAmp4;
                                                                                              offset4=offset4*valueOffsetAmp[indexAmp4+1];
                                                                                              scale_max_ch4=valueAmplitude[indexAmp4]+offset4;
                                                                                              scale_min_ch4=-valueAmplitude[indexAmp4]+offset4; 
                                                                                              }
                                                        if(indexAmp4>2){
                                                            ampl=(valueAmplitude[indexAmp4]/4)*1000;
                                                            $("#l4").val(ampl+"mV");
                                                        }
                                                        else{ampl=valueAmplitude[indexAmp4]/4;
                                                             $("#l4").val(ampl+"V");
                                                        }
                                                        scale_curs=scale_max_ch4;
                                                        break;
                                                      
                                                 }cursorsline();
                                                  draw_graph();
                                            }
            /*-----------------------offset------------------------*/
            function Offsetgraph(x,dat){
                                        switch(ch){case 1:if(x=='positive') {offset1=offset1-0.001;
                                                                             scale_min_ch1=scale_min_ch1-0.001;
                                                                             scale_max_ch1=scale_max_ch1-0.001;
                                                                            
                                                                            }
                                                          else if(x=='negative'){offset1=offset1+0.001;
                                                                                 scale_min_ch1=scale_min_ch1+0.001;
                                                                                 scale_max_ch1=scale_max_ch1+0.001;
                                                                                 
                                                                                }
                                                          break;
                                                   case 2:if(x=='positive') {offset2=offset2-0.001;
                                                                             scale_min_ch2=scale_min_ch2-0.001;
                                                                             scale_max_ch2=scale_max_ch2-0.001;
                                                                            
                                                                            }
                                                          else if(x=='negative'){offset2=offset2+0.001;
                                                                                 scale_min_ch2=scale_min_ch2+0.001;
                                                                                 scale_max_ch2=scale_max_ch2+0.001;
                                                                                }
                                                          break;
                                                   case 3:if(x=='positive') {offset3=offset3-0.001;
                                                                             scale_min_ch3=scale_min_ch3-0.001;
                                                                             scale_max_ch3=scale_max_ch3-0.001;
                                                                            }
                                                          else if(x=='negative'){offset3=offset3+0.001;
                                                                                 scale_min_ch3=scale_min_ch3+0.001;
                                                                                 scale_max_ch3=scale_max_ch3+0.001;
                                                                                }
                                                          break;
                                                   case 4:if(x=='positive') {offset4=offset4-0.001;
                                                                             scale_min_ch4=scale_min_ch4-0.001;
                                                                             scale_max_ch4=scale_max_ch4-0.001;
                                                                            }
                                                          else if(x=='negative'){offset4=offset4+0.001;
                                                                                 scale_min_ch4=scale_min_ch4+0.001;
                                                                                 scale_max_ch4=scale_max_ch4+0.001;
                                                                                }
                                                          break;
                                                        
                                                  }draw_graph(dat);
                                        }
            /*------------------function cursors-----------------*/
                      function cursorsline(){var cursors_data={"x1":[],"x2":[],"y1":[],"y2":[]};
                                                                        
                                                                        
                                              if(move_curs==false){if(curs_x1==undefined)  division_par=3;
                                                                   else  division_par=1.1;
                                                                   if(curs_x1<=scaledatamin || curs_x1>=scaledatamax || curs_x1==undefined)
                                                                                                                         curs_x1=scaledatamin/division_par;
                                                                   if(curs_x2<=scaledatamin || curs_x2>=scaledatamax || curs_x2==undefined)
                                                                         curs_x2=scaledatamax/division_par;
                                                                   curs_axes_y();    
                                                                  }move_curs=false;
                                               cursors_data.x1.push({"axey":20,"axex":curs_x1});
                                               cursors_data.x1.push({"axey":-20,"axex":curs_x1});
                                               cursors_data.x2.push({"axey":20,"axex":curs_x2});
                                               cursors_data.x2.push({"axey":-20,"axex":curs_x2});
                                               cursors_data.y1.push({"axey":curs_y1,"axex":scaledatamax});
                                               cursors_data.y1.push({"axey":curs_y1,"axex":scaledatamin});
                                               cursors_data.y2.push({"axey":curs_y2,"axex":scaledatamax});
                                               cursors_data.y2.push({"axey":curs_y2,"axex":scaledatamin});
                                               dat_curs_x1=cursors_data["x1"];
                                               dat_curs_x1.forEach(function(d) {d.axex = +d.axex;
                                                                                d.axey = +d.axey;
                                                                                });
                                               dat_curs_x2=cursors_data["x2"];
                                               dat_curs_x2.forEach(function(d) {d.axex = +d.axex;
                                                                                d.axey = +d.axey;
                                                                                });
                                               dat_curs_y1=cursors_data["y1"];
                                               dat_curs_y1.forEach(function(d) {d.axex = +d.axex;
                                                                                d.axey = +d.axey;
                                                                                });
                                               dat_curs_y2=cursors_data["y2"];
                                               dat_curs_y2.forEach(function(d) {d.axex = +d.axex;
                                                                                d.axey = +d.axey;
                                                                                });
                                               var show_Y1=curs_y1*1000,
                                                   show_Y2=curs_y2*1000,
                                                   show_X1=curs_x1*1000,
                                                   show_X2=curs_x2*1000,
                                                   unit_tb_1,
                                                   unit_tb_2;
                                               show_Y1=show_Y1.toFixed(3);
                                               show_Y2=show_Y2.toFixed(3);
                                               show_X1=show_X1.toFixed(3);
                                               var condition_x1=Math.abs(show_X1),
                                                   condition_x2=Math.abs(show_X2);
                                               show_X2=show_X2.toFixed(3);
                                               $(".lab_curs_y1").val(show_Y1+"mV");
                                               $(".lab_curs_y2").val(show_Y2+"mV");
                                               if(condition_x1>=1) unit_tb_1="ms";
                                               else {unit_tb_1="µs";
                                                     show_X1=show_X1*1000;
                                                     show_X1=show_X1.toFixed(3);
                                                    }
                                               if(condition_x2>=1)  unit_tb_2="ms";
                                               else {unit_tb_2="µs";
                                                     show_X2=show_X2*1000;
                                                     show_X2=show_X2.toFixed(3);
                                                     }
                                               $(".lab_curs_x1").val(show_X1+unit_tb_1);
                                               $(".lab_curs_x2").val(show_X2+unit_tb_2);
                                               delt_cursors();
                                               }
              /*----------------- move cursors--------*/
            function line_curs(dirction){move_curs=true;
                                         incr_value();
                                         if(type_setting=='fine')
                                                incr_value_x=(timebase/((num_points)/10))*2;
                                         else incr_value_x=(timebase/((num_points)/10))*10;
                                        switch(curs){case "x1":if(dirction=="positive" && curs_x1<scaledatamax)
                                                                curs_x1=curs_x1+incr_value_x;
                                                                else if(curs_x1>scaledatamin)  curs_x1=curs_x1-incr_value_x;
                                                                break;
                                                      case "x2":if(dirction=="positive" && curs_x2<scaledatamax )
                                                                curs_x2=curs_x2+incr_value_x;
                                                                else if(curs_x2>scaledatamin)  curs_x2=curs_x2-incr_value_x;
                                                                break;
                                                      case "y1":if(dirction=="positive" &&  curs_y1 < scale_curs)
                                                                curs_y1=curs_y1+incr_offset_curs;
                                                                else if(curs_y1 > -scale_curs) curs_y1=curs_y1-incr_offset_curs;
                                                                break;
                                                      case "y2":if(dirction=="positive" &&  curs_y2 < scale_curs)
                                                                curs_y2=curs_y2+incr_offset_curs;
                                                                else if(curs_y2 > -scale_curs) curs_y2=curs_y2-incr_offset_curs;
                                                                break;
                                                      }
                                          cursorsline();
                                          draw_graph();
                
                                          }
            function incr_value(){var divi_scale_par; 
                                  if(type_setting=='fine')
                                      divi_scale_par= 58;
                                  else divi_scale_par=10;
                                  switch(ch){case 1:incr_offset_curs= scale_max_ch1/divi_scale_par;
                                                    break;
                                             case 2:incr_offset_curs= scale_max_ch2/divi_scale_par;
                                                    break;
                                             case 3:incr_offset_curs= scale_max_ch3/divi_scale_par;
                                                    break;
                                             case 4:incr_offset_curs= scale_max_ch4/divi_scale_par;
                                                    break;
                                            }
                
                                  }
            function curs_axes_y(){switch(ch){case 1:if(curs_y1<=scale_min_ch1||curs_y1>=scale_max_ch1||curs_y1==undefined)
                                                        curs_y1=scale_min_ch1/division_par;
                                                     if(curs_y2<=scale_min_ch1||curs_y2>=scale_max_ch1||curs_y2==undefined)
                                                        curs_y2=scale_max_ch1/division_par;
                                                      
                                                      break;
                                              case 2:if(curs_y1<=scale_min_ch2||curs_y1>=scale_max_ch2||curs_y1==undefined)
                                                        curs_y1=scale_min_ch2/division_par;
                                                     if(curs_y2<=scale_min_ch2||curs_y2>=scale_max_ch2||curs_y2==undefined)
                                                        curs_y2=scale_max_ch2/division_par;
                                                     
                                                     break;
                                              case 3:if(curs_y1<=scale_min_ch3||curs_y1>=scale_max_ch3||curs_y1==undefined)
                                                        curs_y1=scale_min_ch3/division_par;
                                                     if(curs_y2<=scale_min_ch3||curs_y2>=scale_max_ch3||curs_y2==undefined)
                                                        curs_y2=scale_max_ch3/division_par;
                                                     
                                                     break;
                                              case 4:if(curs_y1<=scale_min_ch4||curs_y1>=scale_max_ch4||curs_y1==undefined)
                                                        curs_y1=scale_min_ch4/division_par;
                                                     if(curs_y2<=scale_min_ch4||curs_y2>=scale_max_ch4||curs_y2==undefined)
                                                        curs_y2=scale_max_ch4/division_par;
                                                      
                                                      break;
                                              }
                                    
                                  }
function delt_cursors(){var un_time_B;
                        delta_cursors_XX=Math.abs(curs_x1-curs_x2);
                        delta_cursors_YY=Math.abs(curs_y1-curs_y2);
                        delta_cursors_XX= delta_cursors_XX*1000;
                        delta_cursors_YY= delta_cursors_YY*1000;
                        delta_cursors_YY=delta_cursors_YY.toFixed(3);                
                        if(delta_cursors_XX>=1000){un_time_B="s";
                                                   delta_cursors_XX=delta_cursors_XX/1000;
                                                   delta_cursors_XX=delta_cursors_XX.toFixed(3);
                                                  }
                        else if(delta_cursors_XX>=1 && delta_cursors_XX<1000) {un_time_B="ms";
                                                                               delta_cursors_XX=delta_cursors_XX.toFixed(3);
                                                                                }
                        else {un_time_B="µs";
                              delta_cursors_XX=delta_cursors_XX*1000;
                              delta_cursors_XX=delta_cursors_XX.toFixed(3);
                            }
                        $('.lab_delta_X').val(delta_cursors_XX+un_time_B);
                        $('.lab_delta_Y').val(delta_cursors_YY+"mV");
    }

 function send_data(){var ws = new WebSocket('ws://192.168.100.14:8080/');
                     $(".picture").css("background-image", "url('Image/inverting.svg')");
     ws.onopen = function() {console.log('Connected to server');
                                       var data={param:"0000000000000001",
                                                 pot1:r1,
                                                 pot0:r2};
                                       var data1={param:"0000000000000010",
                                                 pot1:r1,
                                                 pot0:r2};
                                       ws.send(JSON.stringify(data));
                                       setTimeout(500);
                                       ws.send(JSON.stringify(data1));
                                       ws.close();
                                       
                                       
                                      };
               ws.onclose = function() {getdatascpi_ajax('datach1');
                                        console.log('Disconnected from server');
                                        };               
         
     }
function changepot() {
   r1= document.getElementById("myRange").value;
    r2= document.getElementById("myRange2").value;
   var rs1=(r1*10000/127)+75;
   var rs2=(r2*10000/127)+75;
  document.getElementById("R1").innerHTML ='R1: '+rs1.toFixed(0)+' ohm';
    document.getElementById("R2").innerHTML ='R2: '+rs2.toFixed(0)+' ohm';
     }
