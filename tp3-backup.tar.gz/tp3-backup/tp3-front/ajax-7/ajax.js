var valeur;
var val;
var increment=1;
var incr;
var x=0;
var max;
var v=0;
var $y;
var $u;
var $z=1;
var c;
var $cu;
var $pc;
var $vo;
var $put;
var d=1;
var vi;
var star;
var end;
var e;
var e1;
var e3;
var input;
var m=0;
$host="172.16.5.34";
$port=5025;

 /* function ajaxFunction(){
               var ajaxRequest;  // The variable that makes Ajax possible!
               
               try {
                  // Opera 8.0+, Firefox, Safari
                  ajaxRequest = new XMLHttpRequest();
               }catch (e) {
                  // Internet Explorer Browsers
                  try {
                     ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                  }catch (e) {
                     try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                     }catch (e){
                        // Something went wrong
                        alert("Your browser broke!");
                        return false;
                     }
                  }
               }
			   ajaxRequest.onreadystatechange = function(){
                  if(ajaxRequest.readyState == 4){
                   var ajaxDisplay = document.getElementById('text');
                     ajaxDisplay.innerHTML = ajaxRequest.responseText;
                  }
               }
			    
               var B=1;
           
            
              
                 ajaxRequest.open("GET", "pow.php" ,B, true);
                 ajaxRequest.send(null); 
            //  document.getElementById('text').value=ajaxRequest.responseText;
	
	
	
	
		   }
*/
var a1=0;
var a2=0;

                        /* function On instrument */
function ajaxFunction(){document.getElementById('text').style.display = 'inline';
                        document.getElementById('text2').style.display = 'inline';
						document.getElementById('text3').style.display = 'inline';
						document.getElementById('text4').style.display = 'inline';
						document.getElementById('power').disabled = true;
	                    
                       
					 // for(var i=1;i<=4;i++){
					                    // if(i==1){
						                            $.ajax({type:"GET",
						                            url:"conct1.php",
						                            data:{g: $host, h: $port},
						                            cache:false,
						                            success:function(html){
						                                                      $('#text').val(html);
																			/*  c = document.getElementById('text').value;
																			  c=parseFloat(c);
																			  c = c.toPrecision(5);
  																			  document.getElementById('text').value=c;*/
						                                                  }
						                                    })   
												 //  }                   
										 
                                        // if(i==2){
											 $.ajax({type:"GET",
					                                       url:"conct2.php",
						                                   data:{g: $host, h: $port},
						                                   cache:false,
						                                     success:function(html){
                                                                                    $('#text2').val(html);
																					/*c = document.getElementById('text2').value;
																			        c=parseFloat(c);
																			        c = c.toPrecision(5);
  																			        document.getElementById('text2').value=c;*/
					                                                               }
						                                     })
			                                     //  }
                                          //if(i==3){ 
										  $.ajax({type:"GET",
					                                         url:"conct3.php",
						                                     data:{g: $host, h: $port},
						                                     cache:false,
						                                     success:function(html){
                                                                                    $('#text3').val(html);
																					/*c = document.getElementById('text3').value;
																			        //c=toString(c);
																					vi=c.substring(8,10);
																					c=c.substring(0, 6);
																				//    c = c.toFixed(1);
																				 // c = parseFloat(c);
																				  /* if(vi==01){ c=c.substring(0, 6);
																				               c=c*100
																				               v=1;
																						       c = c.toFixed(1);
																						       document.getElementById('text5').value=v;
																				               }
																					else { v=0;
																					       c=c.toFixed(3);
																						   document.getElementById('text5').value=v;
																					       }
																					//c = c.toPrecision(4);*/
  																			       // document.getElementById('text3').value=c;
					                                                                 
					                                                               }
						                                   })
			                                   //  }                                          
										  //  if(i==4){
										//
										$.ajax({type:"GET",
					                                         url:"conct4.php",
						                                     data:{g: $host, h: $port},
						                                     cache:false,
						                                    success:function(html){
                                                                                    $('#text4').val(html);
																					//c = document.getElementById('text4').value;
																			        
																				   //if(c<1){ c=c*1000;
																				      //     v=1;
																					//	   c = c.toFixed(1);
																				//               }
																					//else { v=0;
																					 //      c=c.toFixed(2);
																					     }    
  																			       // document.getElementById('text4').value=c;

						                                    })
			                                     // }           
										// } 
						
						}						
function ajaxOutP(x){var $p=x;
	                     
					    if((a1==1 && x==1) || (a2==1 && x==2)){if(x==1){a1=0;
											                             document.getElementById('btn1').style.backgroundColor = "";
																		  document.getElementById('text').style.color = "";
																				       document.getElementById('text3').style.color = "";
						                                                 }
											                   else if(x==2){ a2=0;
															                 document.getElementById('btn2').style.backgroundColor = "";
																			 document.getElementById('text2').style.color = "";
																				   document.getElementById('text4').style.color = "";
											 				                }
	                                                           $.ajax({type:"GET",url:"pow1.php",data:{g: $p,h: $host,r: $port},cache:false})
                                                            }	
						
						else if((a1==0 && x==1) || (a2==0 && x==2)){if(x==1){a1=1;
						                                                      document.getElementById('btn1').style.backgroundColor ='white';
																			  if(m==1){document.getElementById('text').style.color ='green';
																				       document.getElementById('text3').style.color ='green';
																			           }
																			 else {document.getElementById('text').style.color = "";
																				       document.getElementById('text3').style.color = "";
																			           }
						                                                     }
											                       else if(x==2) {a2=1;
																                 document.getElementById('btn2').style.backgroundColor ='white';
																                   if(m==1){document.getElementById('text2').style.color ='green';
																				       document.getElementById('text4').style.color ='green';
																			           }
																			 else {document.getElementById('text2').style.color = "";
																				   document.getElementById('text4').style.color = "";
																			           }
																				  }
	                                                               $.ajax({type:"GET",url:"pow.php",data:{g: $p,h: $host,r: $port},cache:false})
						                                          }
										}
function ajaxMaster(){$p=0;
                if(m==0){m=1;$b=1
	                   $.ajax({type:"GET",url:"mast.php",data:{g: $p},cache:false})
				         document.getElementById('mas').style.backgroundColor ='white'; 
						  if(a2==1){document.getElementById('text2').style.color ='green';
								    document.getElementById('text4').style.color ='green';
							     $.ajax({type:"GET",url:"cu2.php",data:{g: $b},cache:false,success:function(html){$('#text4').val(html)}})
								   }
						  else if(a2==0){document.getElementById('text2').style.color = "";
								   document.getElementById('text4').style.color = "";
							             }	
                          if(a1==1){document.getElementById('text').style.color ='green';
								   document.getElementById('text3').style.color ='green';
							      $.ajax({type:"GET",url:"cu1.php",data:{g: $b},cache:false,success:function(html){$('#text3').val(html)}})
								  }
						  else if(a1==0){document.getElementById('text').style.color = "";
								   document.getElementById('text3').style.color = "";
							             }											 
						  }
				else {$.ajax({type:"GET",url:"mast1.php",data:{g: $p},cache:false});
				        m=0; 
						document.getElementById('text').style.color = "";
								   document.getElementById('text3').style.color = "";
								   document.getElementById('text2').style.color = "";
								   document.getElementById('text4').style.color = "";
						document.getElementById('mas').style.backgroundColor = "";
						}
                       }
function disabled1(){document.getElementById("text").disabled=true;
                     document.getElementById("text2").disabled=true;
					 document.getElementById("text4").disabled=true;
					 document.getElementById("text3").disabled=true;
					 x=1;
					// valeur=document.getElementById('text').value;
		//			 document.getElementById("ch2").style.backgroundColor = "";
//					 document.getElementById("ch1").style.backgroundColor = 'white';
                    }
function disabled2(){document.getElementById("text2").disabled=true;
                     document.getElementById("text").disabled=true;
					 document.getElementById("text3").disabled=true;
					 document.getElementById("text4").disabled=true;
					 x=2;
					// valeur=document.getElementById('text2').value;
                    document.getElementById("ch1").style.backgroundColor = "";
					 document.getElementById("ch2").style.backgroundColor = 'white';
					
					}
function disabled3(){if(x==1){
	                          document.getElementById("text3").disabled=true;
                              document.getElementById("text").disabled=false;
                                       // d==2;
							           //val=document.getElementById('text3').value;
									   valeur=document.getElementById('text').value;
					                   increment=1;
									   star = 0;
                                       end = 1;
									   if(valeur>=10){//star=1;
									                  //end=2;
													  e=1;
										               }
										else {//star=0;
									          //end=1;
											  e=0;
										    }
									   var input = document.getElementById ("text");
                                       if ('selectionStart' in input) {
                                                                       input.selectionStart = star + e;
                                                                       input.selectionEnd = end + e;
                                                                       input.focus ();
                                                                       }
									  }
				              //else if(d==2){document.getElementById("text").disabled=true;
                                          //  document.getElementById("text3").disabled=true;
						                  //  d=1;
					                      // }
                            // } 
					 else if(x==2){document.getElementById("text4").disabled=true;
                                   document.getElementById("text2").disabled=false;
                                   valeur=document.getElementById('text2').value;
								   increment=1;
									   star = 0;
                                       end = 1;
								   if(valeur>=10){//star=1;
									             // end=2;
											      e=1;
										               }
										else {//star=0;
									          //end=1;
											  e=0;
										    }
									   var input = document.getElementById ("text2");
                                       if ('selectionStart' in input) {
                                                                       input.selectionStart = star + e;
                                                                       input.selectionEnd = end + e;
                                                                       input.focus ();
                                                                       }      

										  // d=1; 
							           //val=document.getElementById('text3').value;
									        valeur=document.getElementById('text2').value;
					                     //  }
				              /*else if(d==2){document.getElementById("text2").disabled=true;
                                            document.getElementById("text4").disabled=true;
						                    d=1;
					                       }*/
						 
					               }
					 }
function disabled4(){if(x==1){
	                          document.getElementById("text").disabled=true;
                              document.getElementById("text3").disabled=false;
                                     //   d==2;
									var $y=1;
									 star=0;
			                         end=1;
                                $.ajax({type:"GET",url:"curr1.php",data:{g:$y},cache:false,success:function(html){
                                                                                                               $('#text3').val(html);							          
									                                                                           val=document.getElementById('text3').value;
								                                                                               vi=val.substring(8,10);
																											   val=val.substring(0,6);
																											   val=parseFloat(val);
																											   if(vi>=01) {if(vi==01) val=val*100;
																											               else if(vi==02) val=val*10;
																														  else if(vi=04) val=val/10;
																														  v=1;
																														   incr=100;
																														  document.getElementById('text3').value=val.toFixed(1);
																														 
																														 }
																											else {
																												document.getElementById('text3').value=val.toFixed(3);
								                                                                                  v=0;
																												  incr=1;
																												  
																												 }
								                                                                                     }
								})
									  
									 /* valeur=document.getElementById('text').value;
					                
									   var input = document.getElementById ("text3");
                                       if ('selectionStart' in input) {
                                                                       input.selectionStart = star;
                                                                       input.selectionEnd = end;
                                                                       input.focus ();
                                                                       }*/
									}
				             /* else if(d==2){document.getElementById("text").disabled=true;
                                            document.getElementById("text3").disabled=true;
						                    d=1;
					                       }
                             } */
					 else if(x==2){document.getElementById("text2").disabled=true;
                                            document.getElementById("text4").disabled=false;
                                         //   d=1; 
										 $y=2;
							              //  val=document.getElementById('text4').value;
										  $.ajax({type:"GET",url:"curr2.php",data:{g:$y},cache:false,success:function(html){
                                                                                                               $('#text4').val(html);							          
									                                                                           val=document.getElementById('text4').value;
								                                                                               vi=val.substring(8,10);
																											   val=val.substring(0,6);
																											  
																											  val=parseFloat(val);
																											  if(vi>=01) {if(vi==01) val=val*100;
																											               else if(vi==02) val=val*10;
																											               else if(vi=04) val=val/10;
																														   v=1;
																														   incr=100;
																														  document.getElementById('text4').value=val.toFixed(1);
																														  }
																											else {document.getElementById('text4').value=val.toFixed(3);
								                                                                                  incr=1;
																												  v=0;
																												  }
										                                                                                    }
								})
									   
                    /* var input = document.getElementById ("text4");
					// input=String(input);
                                       if ('selectionStart' in input) {
                                                                       input.selectionStart = star;
                                                                       input.selectionEnd = end;
                                                                       input.focus ();
                                                                       }*/

				  }
				 if(x==1) input = document.getElementById ("text3");
			     else input = document.getElementById ("text4");;
				 if ('selectionStart' in input) {
                                                                       input.selectionStart = star;
                                                                       input.selectionEnd = end;
                                                                       input.focus ();
                                                                       }
					 }
function Left(){if(!(document.getElementById('text').disabled)|| !(document.getElementById('text2').disabled)){if(!document.getElementById('text').disabled) var input = document.getElementById ("text");
													       else if(!document.getElementById('text2').disabled) var input = document.getElementById ("text2"); 
                                  if(valeur>=10) e=1; else e=0;
								  if(increment==0.001){increment=0.01;
                                                       //document.getElementById('text1').value=increment; 
                                                    
													  // var input = document.getElementById ("text1");
                                                                      star = 3;
                                                                       end= 4 ;
                                                                       

										  }													   
								                       
		                          else if(increment==0.01){increment=0.1;
						                                 //  document.getElementById('text1').value=increment;  
							                                           star = 2  ;
                                                                       end = 3;
                                                                 }  
                                  else {increment=1;
								    //   document.getElementById('text1').value=increment;
								           star = 0;
                                           end = 1;
                                              }
									   if ('selectionStart' in input) { input.selectionStart =star + e ;
                                                                     input.selectionEnd = end + e ;
																			input.focus ();
                                                                                                                                                                }
									   }
					             
				  else if((!document.getElementById('text3').disabled) || (!document.getElementById('text4').disabled)){if(!document.getElementById('text3').disabled){ var input = document.getElementById ("text3");
				                                                                                                                                                         val=document.getElementById("text3").value;
				                                                                                                                                                      }
													                                                                   else if(!document.getElementById('text4').disabled){ var input = document.getElementById ("text4");
					                                                                                                                                                          val=document.getElementById("text4").value;
																													                                                      }
					                                                                                                 
																													   if(v==1){if(val<10 && val>0) e3=2;
																													            else if(val<1) e3=3;
																													            else if(val>=10 && val<100) e3=1;
																													            else if(val>=100) e3=0;
					                                                                                                              if(incr==0.1){incr=1;
																																                star=2;
																																				end=3;
				                                                                                                                          //      document.getElementById('text1').value=incr;
				                                                                                                                                }
				                                                                                                                  else if(incr==1){incr=10;
												                                                                                                   //document.getElementById('text1').value=incr;
																			                                                                       star=1;
																																				   end=2;
												                                                                                                   }
											                                                                                      else if(incr==10){incr=100;
												                                                                                                    //document.getElementById('text1').value=incr;
											                                                                                                       star=0;
																																				   end=1;
																																				   }                         
												                                                                                if ('selectionStart' in input) {
                                                                                                                                                                input.selectionStart =star - e3;
                                                                                                                                                                input.selectionEnd = end - e3;
																																								input.focus ()
                                                                                                                                                                }
									                                                                                                }
																																
																																
																															else if(v==0){if(incr==0.001){incr=0.01;
												                                                                                                      //    document.getElementById('text1').value=incr;
				                                                                                                                                          star=3;
																																						  end=4;
																																				          }
																													             else if(incr==0.01){incr=0.1;
												                                                                                                 //     document.getElementById('text1').value=incr;
																													                                  star=2;
																																				      end=3;
																																					  }
																													             else if(incr==0.1){incr=1;
												                                                                                                    //    document.getElementById('text1').value=incr;
																													                                 star=0;
																																					 end=1;
																																					  }
																													            if ('selectionStart' in input) {
                                                                                                                                                                input.selectionStart =star;
                                                                                                                                                                input.selectionEnd = end;
																																								input.focus ()
                                                                                                                                                                }
																													  
																													  }
																													  }
               
                 }
function Right(){if(!(document.getElementById('text').disabled)|| !(document.getElementById('text2').disabled)){if(!document.getElementById('text').disabled) var input = document.getElementById ("text");
													                                                            else if(!document.getElementById('text2').disabled) var input = document.getElementById ("text2");
	                                            if(valeur>=10) e=1; else e=0;
												if(increment==1){increment=0.1;
						                                         //  document.getElementById('text1').value=increment;
                                                                  star=2;
																  end=3;
																  }
				                   else if(increment==0.1){increment=0.01;
						                               //    document.getElementById('text1').value=increment;  
				                                           star=3;
														   end=4;
														   }
				                  else {increment=0.001;
			                          //  document.getElementById('text1').value=increment;
				                       star=4;
									   end=5;
									   }						 
				                   if ('selectionStart' in input) {
                                                                       input.selectionStart = star + e;
                                                                       input.selectionEnd = end + e;
                                                                       input.focus ();
                                                                       }
								   
								   }
                 else if((!document.getElementById('text3').disabled) || (!document.getElementById('text4').disabled)){if(!document.getElementById('text3').disabled){ var input = document.getElementById ("text3");
				                                                                                                                                                         val=document.getElementById("text3").value;
				                                                                                                                                                      }
													                                                                   else if(!document.getElementById('text4').disabled){ var input = document.getElementById ("text4");
					                                                                                                                                                          val=document.getElementById("text4").value;
																													                                                      }
																													   if(v==1){if(val<10 && val>0) e2=2;
																													            else if(val<1) e2=3;
																													            else if(val>=10 && val<100) e2=1;
																													            else if(val>=100) e2=0;
																													   
																													            if(incr==100){incr=10;
												                                                                                          //     document.getElementById('text1').value=incr;
				                                                                                                                               star=1;
																																			   end=2;
																																			   }
																													             else if(incr==10){incr=1;
												                                                                                              //    document.getElementById('text1').value=incr;
																													                              star=2;
																																			      end=3;    
																																				  }
																													              else if(incr==1){incr=0.1;
												                                                                                                //   document.getElementById('text1').value=incr;
																													                               star=4;
																																			       end=5;
																																				   }
				                                                                                                                 /* else if(incr==1){incr=0.1;
												                                                                                                   document.getElementById('text1').value=incr;
				                                                                                                                                  }*/
																													               if ('selectionStart' in input) {//star= star - e1;
																																                                  // end= end - e1;
                                                                                                                                                                   input.selectionStart = star - e2;
                                                                                                                                                                   input.selectionEnd = end - e2;
                                                                                                                                                                   input.focus ();
                                                                                                                                                                   }
																													                
																																	
																																	}
																														else if (v==0){if(incr==1){incr=0.1;
																														                        //   document.getElementById('text1').value=incr;
																																		           star=2;
																																				   end=3;
																																				   }
																														                else if(incr==0.1){incr=0.01;
																														                              //    document.getElementById('text1').value=incr; 
																																						  star=3;
																																				          end=4;
																																						  }
																																			else if(incr==0.01){incr=0.001;
																														                                    //    document.getElementById('text1').value=incr;			   
																														      									star=4;
																																				                end=5;																							 
																																			                    }
																																	  if ('selectionStart' in input) {
                                                                                                                                                                   input.selectionStart = star;
                                                                                                                                                                   input.selectionEnd = end;
                                                                                                                                                                   input.focus ();
                                                                                                                                                                   }                          		
																													        
																															}     
			                                                                                                               }
                				
								}
function modifier() {//$.ajax({type:"GET",url:"curr.php",data:{g: $cu},cache:false, success:function(html){
						                                                     
						                                               ///   }
						                                   // })   
														   $b=1;
                                                        
													  if(!document.getElementById('text2').disabled){$z=2;
                                                      if(valeur<32.050){
													  valeur=document.getElementById('text2').value;
                                                      if((valeur<=31.050 && increment==1)||(valeur<31.950 && increment==0.1)||(valeur < 32.040 && increment==0.01)||(valeur<32.050 && increment==0.001)){
  													  valeur-=-increment;
                                                      document.getElementById('text2').value=valeur.toFixed(3);
													  var input=document.getElementById("text2");
													  if('selectionStart' in input){if(valeur>=10){
										                                                           input.selectionStart=star+1;
													                                               input.selectionEnd=end+1;																					
									                                                               input.focus();
									                                                                 }
																	                 else {
										                                                    input.selectionStart=star;
													                                        input.selectionEnd=end;																					
									                                                       input.focus();
									                                                       } 
													                         }
													  max = val*valeur;
                                                                     /* if(valeur>=10) {if(max>50){
																	                              val=50/valeur;
																	                              max= valeur*val;
																								  document.getElementById('text4').value=val.toFixed(3);
																								}
																			                    }
																		else if(valeur<10){val=5;
																		                    document.getElementById('text4').value=val.toFixed(3);
																		                     v=0;
																							 max=5;
																		                     }	*/	}				
                                                                                                     }
								//  $.ajax({type:"GET",url:"cu2.php",data:{g: $b},cache:false,success:function(html){$('#text4').val(html)}})
													  } 
                                  else if (!document.getElementById('text').disabled) {$z=1;
								        if(valeur<5.000){
									    valeur=document.getElementById('text').value;
                                        if((valeur<=4.050 && increment==1)||(valeur<4.950 && increment==0.1)||(valeur<4.040 && increment==0.01)||(valeur<=4.050 && increment==0.001)){
										valeur-=-increment;
									    document.getElementById('text').value=valeur.toFixed(3);
                                       var input=document.getElementById("text");
									   if('selectionStart' in input){if(valeur>=10){
										                             input.selectionStart=star+1;
													                 input.selectionEnd=end+1;																					
									                                 input.focus();
									                                                }
																	 else {
										                             input.selectionStart=star;
													                 input.selectionEnd=end;																					
									                                 input.focus();
									                                                }
														                           }
    									   max = val*valeur;
                                      /*  if(valeur>=10) {if(max>50){
																   val=50/valeur;
															       max= valeur*val;
															       document.getElementById('text3').value=val.toFixed(3);
														    	  }
								                        }
									   else if(valeur<10){val=5;
													      document.getElementById('text3').value=val.toFixed(3);
														  
														  v=0;
														  max=5;
											            }	*/		
									 }   
									}
						           // $.ajax({type:"GET",url:"cu1.php",data:{g: $b},cache:false,success:function(html){$('#text3').val(html)}})
								  }
								   
								   
								   								   
                //incr Curent
                                                                                                           else if(!document.getElementById('text4').disabled){val=document.getElementById('text4').value;
					                                                                                                                                           valeur=document.getElementById('text2').value;
																																							   $cu=2;
																																							 //  input=document.getElementById("text4");
																																									   if(v==0){e1=0;
																																										if(valeur < 10){e1=0;
																																										                if((val<4.000 && incr==1)||(val<4.900 && incr==0.1)||(val<=4.990 && incr==0.01)||(val<=4.999 && incr==0.001)){
																																														          val-=-incr;
																																														          document.getElementById('text4').value=val.toFixed(3);
																																														          
																																																   }
																																										                }
																																									  
                                                                                                                         												else if (valeur>=10){
																																											                  var T;
																																										                      var T1;
																																															  var T2;
																																															  var T3;
																																										                      max=50/valeur;
																																															
																																															  if(incr==1){T=max-1;}
																																															  else if(incr==0.1) T1=max-0.1;
																																															  else if(incr==0.01) T2=max-0.01;
																																															  else if (incr==0.001) T3=max-0.001;
																																															  if((val<T && incr==1)||(val<T1 && incr==0.1)||(val<T2 && incr==0.01)||(val<=T3 && incr==0.001)){
																																															 // document.getElementById('text8').value=max.toFixed(3);
																																											                  if(val < max){val-=-incr;
                                                                                                                                                                                             }  
																																														   document.getElementById('text4').value=val.toFixed(3);
																																											              }
																																										     }
                            																																			     	 }
																																										if(v==1){if(val<10 && val>0) e1=2;
																													                                                            else if(val<1) e1=3;
																													                                                            else if(val>=10 && val<100) e1=1;
																													                                                            else if(val>=100) e1=0;
																																												if(val<=1000) {
																																											                     val-=-incr;
																																										                         if(val>=1000){val=val/1000;
																																																               v=0;
																																																			   incr=0.001;
																																																			//   document.getElementById('text9').value=v;
																																																                }
																																															   
																																															   document.getElementById('text4').value=val.toFixed(1);
																																										                       }
																																												
																																												}
																																												input=document.getElementById("text4");
																																										  if('selectionStart' in input){
										                                                                                                                                                                input.selectionStart=star - e1;
													                                                                                                                                                    input.selectionEnd=end - e1;																					
									                                                                                                                                                                    input.focus();
									                                                                                                                                                                     }         
																																										}
				                                                                                                      else if(!document.getElementById('text3').disabled){val=document.getElementById('text3').value;
					                                                                                                                                                      valeur=document.getElementById('text').value;
																																										  $cu=1;
																																										//  input=document.getElementById("text3");
																																									    if(v==0){e1=0;
																																										if(valeur < 10){
																																										                if((val<4.000 && incr==1)||(val<4.900 && incr==0.1)||(val<=4.990 && incr==0.01)||(val<=4.999 && incr==0.001)){
																																														          val-=-incr;
																																														          document.getElementById('text3').value=val.toFixed(3);
																																														           }
																																										                }
																																									  
                                                                                                                         												else if (valeur>=10){var T;
																																										                      var T1;
																																															  var T2;
																																															  var T3;
																																										                      max=50/valeur;
																																															
																																															  if(incr==1){T=max-1;}
																																															  else if(incr==0.1) T1=max-0.1;
																																															  else if(incr==0.01) T2=max-0.01;
																																															  else if (incr==0.001) T3=max-0.001;
																																															  if((val<T && incr==1)||(val<T1 && incr==0.1)||(val<T2 && incr==0.01)||(val<=T3 && incr==0.001)){
																																															 // document.getElementById('text8').value=max.toFixed(3);
																																											                  if(val < max){val-=-incr;
                                                                                                                                                                                             }  
																																														   document.getElementById('text3').value=val.toFixed(3);
																																											              }
																																										     }
                            																																			     	 }
																																										if(v==1){if(val<10 && val>0) e1=2;
																													                                                            else if(val<1) e1=3;
																													                                                            else if(val>=10 && val<100) e1=1;
																													                                                            else if(val>=100) e1=0;
																																												if(val<=1000) {
																																											                     val-=-incr;
																																										                         if(val>=1000){val=val/1000;
																																																               v=0;
																																																			   incr=0.001;
																																																			//   document.getElementById('text9').value=v;
																																																                }
																																															 //  $u=val*1000;
																																															   document.getElementById('text3').value=val.toFixed(1);
																																										                       }
																																											 //$u=val*1000;
																																												  //$u=val;
																																												 // $z=1;	 
																																												}
																																										// $.ajax({type:"GET",url:"pow6.php",data:{g: $u, h: $z},cache:false})
																																										input=document.getElementById("text3");
																																										if('selectionStart' in input){
										                                                                                                                                                                input.selectionStart=star - e1;
													                                                                                                                                                    input.selectionEnd=end - e1;																					
									                                                                                                                                                                    input.focus();
									                                                                                                                                                                     }          
																																										 
																																										 
																																										} 
																														
								  
								 // $z=1;
								//  $.ajax({type:"GET",url:"pow5.php",data:{g: $y, h:$z},cache:false})
																														//$.ajax({type:"GET",url:"pow6.php",data:{g: $u, h: $z},cache:false})
																														 
				if(v==1) val=val/1000;
				$pc=val;
                $put=valeur;				
                $.ajax({type:"GET",url:"pow5.php",data:{g: $z, h: $put},cache:false})
				$.ajax({type:"GET",url:"pow6.php",data:{g: $cu, h: $pc},cache:false})
				}
function modifier1(){if(!(document.getElementById('text').disabled)|| !(document.getElementById('text2').disabled)){if((valeur>=1.000 && increment==1)||(valeur>=0.199 && increment==0.1)||(valeur>0.009 && increment==0.01)||(valeur>=0.001 && increment==0.001)){
                                                  if(!document.getElementById('text2').disabled){$z=2;
                                                                                               valeur=document.getElementById('text2').value;
                                                                                               valeur-=increment;
                                                                                               document.getElementById('text2').value=valeur.toFixed(3);
													                                            var input=document.getElementById("text2");
									                                                             if('selectionStart' in input){if(valeur>=10){
										                                                                                                      input.selectionStart=star+1;
													                                                                                          input.selectionEnd=end+1;																					
									                                                                                                          input.focus();
									                                                                                                          }
																	                                                           else {
										                                                                                             input.selectionStart=star;
													                                                                                 input.selectionEnd=end;																					
									                                                                                                 input.focus();
									                                                                                                }
														                                                                       }
																			                    }																				 
                                                                                                     
                                                  else if(!document.getElementById('text').disabled) {if((valeur>=1.000 && increment==1)||(valeur>=0.199 && increment==0.1)||(valeur>0.009 && increment==0.01)||(valeur>=0.001 && increment==0.001)){
												        $z=1;
														valeur=document.getElementById('text').value;
                                                        valeur-=increment;
                                                        document.getElementById('text').value=valeur.toFixed(3);
                                                        var input=document.getElementById("text");
									   if('selectionStart' in input){if(valeur>=10){
										                                             input.selectionStart=star+1;
													                                 input.selectionEnd=end+1;																					
									                                                 input.focus();
									                                                }
																	 else {
										                             input.selectionStart=star;
													                 input.selectionEnd=end;																					
									                                 input.focus();
									                                                }
														                           }
														}
							                            }			
									               }
						           }
                 //decr cur
				    else if((!document.getElementById('text3').disabled) || (!document.getElementById('text4').disabled)){if(!document.getElementById('text4').disabled){val=document.getElementById('text4').value;
					                                                                                                                                                     $cu=2;
					                                                                                                                                                   document.getElementById('text5').value=v;
					                                                                                                                                                    if(v==0){if(val==1.000){incr=0.1;
																																										                        val-=incr;
																																																val=val*1000;
																																																v=1;
																																																e1=0;
																																																document.getElementById('text5').value=v;
																																										                         document.getElementById('text4').value=val.toFixed(1);
																																																 }
																																										        else if(val>1.000){if(incr==1 && val<2) {val-=incr;
																																												                                          val=val*1000;
																																																						  v=1;
																																												                                          document.getElementById('text4').value=val.toFixed(1);
																																																						 }
																																																   else{
																																																   val-=incr;
																																											                       if(val<0){val=Math.abs(val*1000);
																																															                 v=1;
																																																			 document.getElementById('text5').value=v;
																																															                 document.getElementById('text4').value=val.toFixed(1);
																																																		    }

                                                             																													                 else document.getElementById('text4').value=val.toFixed(3);
																																															                } 
																																																		}	
																																										                       
																																												  }  
                                         																																	if(v==1){if((val>0.5 && incr==0.1)||(val>1.9 && incr==1)||(val>19.9 && incr==10)||(val>199.9 && incr==100)) {val-=incr;
																																											             document.getElementById('text5').value=v;      
																																														 document.getElementById('text4').value=val.toFixed(1);
																																														 if(val<10 && val>0) e1=2;
																													                                                            else if(val<1) e1=3;
																													                                                            else if(val>=10 && val<100) e1=1;
																													                                                            else if(val>=100) e1=0;
																																																  }
																																											          }
																																											input=document.getElementById("text4");
																																											if('selectionStart' in input){
										                                                                                                                                                                input.selectionStart=star - e1;
													                                                                                                                                                    input.selectionEnd=end - e1;																					
									                                                                                                                                                                    input.focus();
									                                                                                                                                                                     } 
																																											
																																									       }
                                                                                                                          else if(!document.getElementById('text3').disabled){val=document.getElementById('text3').value;
																														                                                       $cu=1;
					                                                                                                                                                   document.getElementById('text5').value=v;
					                                                                                                                                                    if(v==0){if(val==1.000){incr=0.1;
																																										                        val-=incr;
																																																val=val*1000;
																																																v=1;
																																																e1=0;
																																																document.getElementById('text5').value=v;
																																										                         document.getElementById('text3').value=val.toFixed(1);
																																																 }
																																										        else if(val>1.000){if(incr==1 && val<2) {val-=incr;
																																												                                          val=val*1000;
																																																						  v=1;
																																																						  document.getElementById('text5').value=v;
																																												                                          document.getElementById('text3').value=val.toFixed(1);
																																																						 }
																																																   else{
																																																   val-=incr;
																																											                       if(val<0){val=Math.abs(val*1000);
																																															                 v=1;
																																																			 document.getElementById('text5').value=v;
																																															                 document.getElementById('text3').value=val.toFixed(1);
																																																		    }

                                                             																													                 else document.getElementById('text3').value=val.toFixed(3);
																																															                } 
																																																		}	
																																										                       
																																												  }  
                                         																																	if(v==1){if((val>0.5 && incr==0.1)||(val>1.9 && incr==1)||(val>19.9 && incr==10)||(val>199.9 && incr==100)) {val-=incr;
																																											              document.getElementById('text5').value=v;      
																																																 document.getElementById('text3').value=val.toFixed(1);
																																																																																														 if(val<10 && val>0) e1=2;
																													                                                            else if(val<1) e1=3;
																													                                                            else if(val>=10 && val<100) e1=1;
																													                                                            else if(val>=100) e1=0; 
																																																 }
																																											          }
																																											//if(v==1) $u=val*1000;
																																												  //$u=val;
																																												//  $z=1;
																																											input=document.getElementById("text3");
																																											if('selectionStart' in input){
										                                                                                                                                                                input.selectionStart=star - e1;
													                                                                                                                                                    input.selectionEnd=end - e1;																					
									                                                                                                                                                                    input.focus();
									                                                                                                                                                                     } 
																																											
																																											
																																											}																																										

   				             }
			   
                if(v==1) val=val/1000;
				$pc=val;
				$put=valeur;				
                $.ajax({type:"GET",url:"pow5.php",data:{g: $z, h: $put},cache:false})
				$.ajax({type:"GET",url:"pow6.php",data:{g: $cu, h: $pc},cache:false})
				
                  
				  }		

/*function send(){$phase=2;
                var parameters = location.search.substring(1);
	            if($z==1)
                $put=document.getElementById('text').value;
                else  $put=document.getElementById('text2').value;			
				var c,L,pos,res;
				
            //document.getElementById('text2').value=$put;
		/*	document.getElementById('text2').value=$phase;
			document.getElementById('text3').value=$z;----
    		  $.ajax({type:"GET",url:"allQ-ajax.php",data:{ph: $phase,op: $z,pt: $put,em: parameters},cache:false, success:function(html){
						                                                    if($z==1){ 
																			           $('#text').val(html);
																			             c = document.getElementById('text').value;
																			             L=c.length;
																			             pos = c.indexOf("/");
																			           res=c.substring(0, pos);
																			             c=c.substring(pos+1, L);
																			            document.getElementById('text').value=res;
																					  }
																			else {$('#text2').val(html);
																			       c = document.getElementById('text2').value;
																				   L=c.length;
																			       pos = c.indexOf("/");
																			       res=c.substring(0, pos);
																			      c=c.substring(pos+1, L);
																			      document.getElementById('text2').value=res;
																				 }
																				 L=c.length;
																			     pos = c.indexOf("/");
																			     res=c.substring(0, pos);
																			     c=c.substring(pos+1, L);
																			    document.getElementById('text4').value=res;
																			     L=c.length;
																			     pos = c.indexOf("/");
																			     res=c.substring(0, pos);
																			     c=c.substring(pos+1, L);
																			    document.getElementById('textbox').value=res;
																			 L=c.length;
																			     pos = c.indexOf("/");
																			     res=c.substring(0, pos);
																			     c=c.substring(pos+1, L);
																				 document.getElementById('textboxd1').value=res;
																				 L=c.length;
																			     pos = c.indexOf("/");
																			     res=c.substring(0, pos);
																			     c=c.substring(pos+1, L);
																			 document.getElementById('clb1').value=res;
																				L=c.length;
																			   pos = c.indexOf("/");
																			   res=c.substring(0, pos);
																			   c=c.substring(pos+1, L);
																			  document.getElementById('clb1d1').value=res;
																			  L=c.length;
																			   pos = c.indexOf("/");
																			   res=c.substring(0, pos);
																			   c=c.substring(pos+1, L);
																			  document.getElementById('textbox1d1').value=res;
																			  document.getElementById('textbox1').value=c;
																				 
																		   }})
				//$.ajax({type:"GET",url:"pow6.php",data:{g: $cu, h: $pc,host: $host,por: $port},cache:false})
	 
                   }*/
