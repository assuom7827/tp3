var instr={},
    multimeter2=false,
    $msg_PS,
    $msg_Dmm1,
    $msg_Dmm2,
    $func_PS,
    $func_Dmm1,
    $func_Dmm2,
    $role_ps,
    $role_dmm1,
    $role_dmm2="1",
    $msg_PS_I,
    $v1,
    $v2,
    $id,
    $nom_exp,
    ip,
    $volt5,
    s9=0,
    s10=0,
    s11=0,
    s12=0,
    s13=0,
    s14=0,
    sens;
   
var F;

function ipaddr(){$.getJSON('https://api.ipify.org?format=jsonp&callback=?', function(data) {
                             ip=JSON.stringify(data.ip, null, 2);
                           });
                  }
function getFile(){F=0;
                   $id = $("#user_id").val();
                  // $password = $("#password").val();
                  
                   if($id!=""){
                    $.getJSON('ajax-7/json/login.json', function(data) {instr=data["user"];
                                                                         for(i=0;i<Object.keys(instr).length;i++){var ID=instr[i].id_user;
                                                                                    var PW=instr[i].password;
                                                                                    if(ID==$id){$("#pagelogin").hide();
                                                                                                                 $("#digit1").show();
                                                                                                                 loadexperience("experience1");
                                                                                                                F=1 
                                                                                                                }
                                                                                                                 
                                                                                   }         
                                                                      if(F==0) alert("ID incorrect"); 
                                                                       });
                                           
                   }
                   else alert("entre ID user and password please"); 
		 					 
}              
function display_none_instr(){$("#multimeter1").hide();
                              $("#multimeter2").hide();
                              $("#powersupply").hide();
                              multimeter2=false;
                              $('#textbox').val(" ");
                              $('#textbox1').val(" ");
                              $('#clb1').val(" ");
                              $('#textboxd1').val(" ");
                              $('#textbox1d1').val(" ");
                              $('#clb1d1').val(" ");
                              $('#in').val(" ");
                              $('#ind1').val(" ");
                              $("#myRange").hide();
                              $("#myRange2").hide();
                              $("#myRange3").hide();
                              $("#myRange4").hide();
                              $("#R1").hide();
                              $("#R2").hide();
                              $("#R3").hide();
                              $("#R4").hide();
                              
                              }
function loadexperience(experience){$nom_exp=experience;
                                     
                           $.getJSON('ajax-7/json/instrument.json', function(data) {instr=data[experience];
                                                                                     
                                                                                    position();
                                                                                    checked_direction(1);
                                                                                   });
                          
                                   }

function position(){var position_top,position_left;
                   
                    for(i=0;i<Object.keys(instr).length;i++){var name=instr[i].name_inst;
                                                             
                                     var img=instr[i].img;            
                                     var position=instr[i].position;
                                     
                                     if(name=="powersupply") {$msg_PS=instr[i].msg;
                                                              $func_PS=instr[i].function;
                                                              $role_ps=instr[i].role;
                                                              
                                                             }
                                     else if(name=="multimeter1") {$msg_Dmm1=instr[i].msg;
                                                                   $func_Dmm1=instr[i].function;
                                                                   $role_dmm1=instr[i].role;
                                                                   $role_dmm2=$role_dmm1;
                                                                  }
                                     else if(name=="multimeter2") {$msg_Dmm2=instr[i].msg;
                                                                   $func_Dmm2=instr[i].function;
                                                                   $role_dmm2=instr[i].role;
                                                                   
                                                                   multimeter2=true;
                                                                  }
                                                                   
                                     
                                     if(name==undefined){ i=6;
                                                        $role_dmm2=1;
                                                        }
                                     switch(position){case "position1":position_top=60;
                                                                       position_left=35;
                                                                       break;
                                                      case "position2":position_top=310;
                                                                       position_left=20;
                                                                       break;
                                                      case "position3":position_top=540;
                                                                       position_left=20;
                                                                       break;
                                                      }
                                     $("#"+name).css({top:position_top, left: position_left, position:'absolute'});
                                     $("#"+name).show();
                                     
                                                            
                                    }
    
                   }
function checked_direction(checked_etat){if(checked_etat==1){document.getElementById('direct').checked=true;
                                                             document.getElementById('inverse').checked=false;
                                                              $("#img").css("background-image", "url(image/D1_direct.png)");
                                                          
															sens='direct';
                                                            }
                                         else {document.getElementById('direct').checked=false;
                                               document.getElementById('inverse').checked=true;
                                               $("#img").css("background-image", "url(image/D1_inverse.png)");
                                                
												sens='inversé';
                                              }
                             
    
                             }
function send(){$('.btnread').attr("disabled","disabled");
                $volt5=$('#text').val();
                $voltch2=$('#text2').val();
                $msg_PS_I=$msg_PS;
				var led_type,
                    sw_T,
                    sw_C;
                var radi=$('input:radio[name="diode"]:checked').val()
                switch(radi){ case 'Silicium':s9=0;s10=0;s11=0;s12=0;s13=0;s14=1; led_type='Silicium'; break;
                              case 'Germanum':s9=0;s10=0;s11=0;s12=0;s13=1;s14=0;led_type='Germanum'; break;               
                              case 'LED Rouge':s9=0;s10=1;s11=0;s12=0;s13=0;s14=0;led_type='Led Rouge';break;
                              case 'LED Verte':s9=1;s10=0;s11=0;s12=0;s13=0;s14=0;led_type='Led Verte';break;
                              case 'LED Bleue':s9=0;s10=0;s11=0;s12=1;s13=0;s14=0;led_type='Led Bleue';break;
                              case 'LED Jaune':s9=0;s10=0;s11=1;s12=0;s13=0;s14=0;led_type='Led Jaune';break;
                           }
                 if(sens=='direct'){
                                  sw_T='00010011'+s9+s10+s11+s12+s13+s14+'01';
                                  sw_C='00010010'+s9+s10+s11+s12+s13+s14+'11';
                                   }
                  else{sw_T='00001101'+s9+''+s10+''+s11+''+s12+''+s13+''+s14+'01';
                       sw_C='00001100'+s9+''+s10+''+s11+''+s12+''+s13+''+s14+'11';
                      
                  }
                console.log("msg+ "+$msg_PS);
                console.log(sw_T);
                 $msg_PS="INST OUT1\n Volt "+$volt5+"\n"+$msg_PS;
                                       $('.textbox2').css('color','yellow');
                                       $('.textbox').css('color','green');
                                          
                
                 
             
              
                
               
                $.ajax({type:"GET",
                        url:"scpi.php",
                        data:{msg1:$msg_PS,msg2: $msg_Dmm1,msg3: $msg_Dmm2,DMfunc1: $func_Dmm1,PSfunc: $func_PS,DMfunc2: $func_Dmm2,rolePs:$role_ps, roleDm1:$role_dmm1,roleDm2:$role_dmm2,swt:sw_T,swc:sw_C,user: $id,psvolt: $volt5,nom: $nom_exp,ipp: ip,sen: sens,LT:led_type},
                        cache:false, 
                        success:function(val){$('.btnread').attr("disabled",false);
                                                var zone_box=val.split("/");
                                              $('#text4').val(zone_box[1]);
                                              $('#textbox').val(zone_box[2]);
                                              $('#clb1').val(zone_box[3]);
                                              $('#textbox1').val(zone_box[4]);
                                              $('#textboxd1').val(zone_box[5]);
                                              $('#clb1d1').val(zone_box[6]);
                                              $('#textbox1d1').val(zone_box[7]);
                                              if($func_Dmm1=="volt")
                                                             $('#in').val("DC Voltage");
                                                else if($func_Dmm1=="curr") $('#in').val("DC Current");
                                                else $('#in').val("Resistance"); 
                                              if($func_Dmm2=="volt")
                                                                    $('#ind1').val("DC Voltage");
                                              else if($func_Dmm2=="curr") $('#ind1').val("DC Current");
                                              else $('#ind1').val("Resistance"); 
                                              
                                             }
                                              
                          });
             
                $msg_PS=$msg_PS_I;
               }




