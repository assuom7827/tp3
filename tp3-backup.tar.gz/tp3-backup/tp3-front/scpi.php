<?php
$hostM = "192.168.100.204"; //address local Digit Multimetre
$host = "192.168.100.41";  //address local Power Supply
$port = 5025;  //Port pour les sockets  PS
$portM = 5025;
$msgPs=$_GET['msg1'];
$msgDmm=$_GET['msg2'];
$msgDmm2=$_GET['msg3'];
$FuncPs=$_GET['PSfunc'];
$FuncDmm1=$_GET['DMfunc1'];
$FuncDmm2=$_GET['DMfunc2'];
$RolePs=$_GET['rolePs'];
$RoleDmm1=$_GET['roleDm1'];
$RoleDmm2=$_GET['roleDm2'];
$swT=$_GET['swt'];
$swC=$_GET['swc'];
$user=$_GET['user'];
$voltps=$_GET['psvolt'];
$nomExp=$_GET['nom'];
$ip=$_GET['ipp'];
$sens=$_GET['sen'];
$Ltype=$_GET['LT'];
function senddata($pf) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'http://192.168.100.187/gpio.py?v='.$pf);

    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
    curl_setopt($ch, CURLOPT_PORT, 8080);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);

    curl_setopt($ch, CURLOPT_POST, true);

     $v=$pf;

    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($v));

    curl_exec($ch);
    curl_close($ch);
}
$socket  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Hors service\n");
socket_connect($socket, $host, $port) or die("Could not connect to server\n");
socket_write($socket , $msgPs, strlen($msgPs)) or die("Could not send data to server\n");
$result1 = socket_read ($socket , 1024) or die("Could not read server response1\n");
senddata($swT);

usleep(1000);
$socketdmm  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
socket_connect($socketdmm, $hostM, $portM) or die("Could not connect to server\n");
socket_write($socketdmm , $msgDmm, strlen($msgDmm)) or die("Could not send data to server\n");
$resultvol = socket_read ($socketdmm , 1024) or die("Could not read server response2\n");
socket_close($socketdmm);
if($RoleDmm1!=$RoleDmm2){senddata($swC);
                         
                         $socketdmm2  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
                         socket_connect($socketdmm2, $hostM, $portM) or die("Could not connect to server\n");
                         socket_write($socketdmm2 , $msgDmm2, strlen($msgDmm2)) or die("Could not send data to server\n");
                         $resultdmm2 = socket_read ($socketdmm2 , 1024) or die("Could not read server response3\n");
                         socket_close($socketdmm2);
                         
                         switch($FuncDmm2){case 'volt':$signvol=substr($resultdmm2,-4,1);
                                                       $powvol =substr($resultdmm2,12,15);
                                                       $sign1vol2=substr($resultdmm2,-16,1);
                                                       $resultdmm2=substr($resultdmm2,-15,16);
                                                       $resultdmm2=(float)$resultdmm2;
                                                       $powvol=(float)$powvol;
			                                           $resultdmm2 = number_format($resultdmm2, 16, '.', ' ');
			                                           if($powvol>10) $resultdmm2="OverLoad";
                                                       else if($powvol==-06){$resultdmm2 =$resultdmm2*1000000;
								                                             $resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
		    	                                                             $resultrag2="Auto 100mV";
								                                             $resultunitv2="mVDC";
								                                             }
                                                       else if($powvol==-05){$resultdmm2 =$resultdmm2*1000;
								                                             $resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
		    	                                                             $resultrag2="Auto 100mV";
								                                             $resultunitv2="mVDC";
								                                             }

			                                           else if($powvol==-04){$resultdmm2 =$resultdmm2*10000;
								                                             $resultdmm2 = number_format($resultdmm2, 5, '.', ' ');
		    	                                                             $resultrag2="Auto 100mV";
								                                             $resultunitv2="mVDC";
								                                             }
			                                           else if($powvol==-3){$resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
		    	                                                            $resultdmm2 =$resultdmm2*1000;
								                                            $resultrag2="Auto 100mV";
								                                            $resultunitv2="mVDC";
								                                            }
                                                       else if($powvol==-02){$resultdmm2 =$resultdmm2*1000;
								                                             $resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
		    	                                                             $resultrag2="Auto 100mV";
								                                             $resultunitv2="mVDC";
								                                             }	
                                                       else if($powvol==-01){$resultdmm2 = number_format($resultdmm2, 6, '.', ' ');
		    	                                                             $resultrag2="Auto 1V";
									                                         $resultunitv2="VDC";
									                                         }
                                                       else if($powvol==00){$resultdmm2 = number_format($resultdmm2, 5, '.', ' ');
		    	                                                            $resultrag2="Auto 10V";
								                                            $resultunitv2="VDC";
								                                            }	
		                                               else if($powvol==01){$resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
		    	                                                            if($resultdmm2<12) $resultrag2="Auto 10V";
								                                            else $resultrag2="Auto 100V";
								                                            $resultunitv2="VDC";
								                                           }
                                                       break;
                                         case "curr":$signcurr=substr($resultdmm2,-4,1);
                                                     $sign2curr2=substr($resultdmm2,-16,1);
                                                     if($sign2curr2=='-') $sign2curr2="";
                                                     $resultdmm2=(float)$resultdmm2; 
                                                     $pos = strpos($resultdmm2, 'E');
                                                     $resultdmm2 = number_format($resultdmm2, 14, '.', ' ');
                                                     if($pos==false){$resultdmm2=$resultdmm2*1000;
                                                                     if($resultdmm2<=1) {$resultdmm2 = number_format($resultdmm2, 6, '.', ' ');
				                                                                         $resultragc2= "Auto 1mA";
				                                                                         }
				                                                      elseif($resultdmm2<10) {$resultdmm2 = number_format($resultdmm2, 5, '.', ' ');
				                                                                              $resultragc2= "Auto 10mA";
				                                                                              }
				                                                      else {$resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
                                                                            $resultragc2= "Auto 100mA";
				                                                           }
				                                                      $resultunit2= "mADC";
				                                                      } 
                                                     else {$resultdmm2=$resultdmm2*1000000;
	                                                       $resultdmm2 = number_format($resultdmm2, 4, '.', ' ');
                                                           $resultragc2= "Auto 100µA";
	                                                       $resultunit2= "µADC";
	                                                       }
                                                         break;
                                                  
                                    }
                         }
switch($FuncDmm1){case 'volt':$signvol=substr($resultvol,-4,1);
                             $powvol =substr($resultvol,12,15);
                             $sign1vol=substr($resultvol,-16,1);
                             $resultvol=substr($resultvol,-15,16);
                             $resultvol=(float)$resultvol;
                             $powvol=(float)$powvol;
			                 $resultvol = number_format($resultvol, 16, '.', ' ');
			                 if($powvol>10) $resultvol="OverLoad";
                             else if($powvol==-06){$resultvol =$resultvol*1000000;
								                   $resultvol = number_format($resultvol, 4, '.', ' ');
		    	                                   $resultrag="Auto 100mV";
								                   $resultunitv="mVDC";
								                   }
                             else if($powvol==-05){$resultvol =$resultvol*1000;
								                   $resultvol = number_format($resultvol, 4, '.', ' ');
		    	                                   $resultrag="Auto 100mV";
								                   $resultunitv="mVDC";
								                   }

			                 else if($powvol==-04){$resultvol =$resultvol*10000;
								                   $resultvol = number_format($resultvol, 5, '.', ' ');
		    	                                   $resultrag="Auto 100mV";
								                   $resultunitv="mVDC";
								                   }
			                 else if($powvol==-3){$resultvol = number_format($resultvol, 4, '.', ' ');
		    	                                  $resultvol =$resultvol*1000;
								                  $resultrag="Auto 100mV";
								                  $resultunitv="mVDC";
								                  }
                             else if($powvol==-02){$resultvol =$resultvol*1000;
								                   $resultvol = number_format($resultvol, 4, '.', ' ');
		    	                                   $resultrag="Auto 100mV";
								                   $resultunitv="mVDC";
								                   }	
                             else if($powvol==-01){$resultvol = number_format($resultvol, 6, '.', ' ');
		    	                                   $resultrag="Auto 1V";
									               $resultunitv="VDC";
									               }
                             else if($powvol==00){$resultvol = number_format($resultvol, 5, '.', ' ');
		    	                                  $resultrag="Auto 10V";
								                  $resultunitv="VDC";
								                  }	
		                     else if($powvol==01){$resultvol = number_format($resultvol, 4, '.', ' ');
		    	                                 if($resultvol<12) $resultrag="Auto 10V";
								                 else $resultrag="Auto 100V";
								                 $resultunitv="VDC";
								                 }
                            break;
                 case "curr":$signcurr=substr($resultvol,-4,1);
                             $sign2curr=substr($resultvol,-16,1);
                             if($sign2curr=='-') $sign2curr="";
                             $resultvol=(float)$resultvol; 
                             $pos = strpos($resultvol, 'E');
                             $resultvol = number_format($resultvol, 14, '.', ' ');
                             if($pos==false){$resultvol=$resultvol*1000;
                                             if($resultvol<=1) {$resultvol = number_format($resultvol, 6, '.', ' ');
				                                                $resultragc= "Auto 1mA";
				                                               }
				                              elseif($resultvol<10) {$resultvol = number_format($resultvol, 5, '.', ' ');
				                                                     $resultragc= "Auto 10mA";
				                                                     }
				                              else {$resultvol = number_format($resultvol, 4, '.', ' ');
                                                    $resultragc= "Auto 100mA";
				                                   }
				                              $resultunit= "mADC";
				                             } 
                             else {$resultvol=$resultvol*1000000;
	                               $resultvol = number_format($resultvol, 4, '.', ' ');
                                   $resultragc= "Auto 100µA";
	                               $resultunit= "µADC";
	                              }
                             break;
                  case "reas":$result=$resultvol;
                              $pow =substr($result,12,15);
                              if($pow>10) echo "OverLoad";
                              else if($pow==-01){$result=(float)$result;
	                                             $result=$result/10;
							                     $result = number_format($result, 4, '.', ' ');
                                                 $clb="Auto 100Ω";
                                                 $unit="Ω";																							   
												 }
				              else if($pow==+00){$result=(float)$result;
	                                             $result = number_format($result, 4, '.', ' ');
		    	                                 $clb="Auto 100Ω";
                                                 $unit="Ω";
												}
							  else if($pow==+01){$result=(float)$result;
	                                                                                           
							                     $result = number_format($result, 4, '.', ' ');
		    	                                 $clb="Auto 100Ω";
                                                 $unit="Ω";
												 }	
							  else if($pow==+02){$result=(float)$result;
	                                             $result=$result/1000;
							                     $result = number_format($result, 6, '.', ' ');
		    	                                 $clb="Auto 1kΩ";
                                                 $unit="kΩ";
												 }	
				              else if($pow==+03){$result=(float)$result;
												 $result=$result/1000; 
	                                             if($result<=1.2){$result = number_format($result, 6, '.', ' ');
																  $clb="Auto 1kΩ";
                                                                  }
                                                 else {$result = number_format($result, 5, '.', ' ');
												       $clb="Auto 10kΩ";
                                                       }
												$unit="kΩ";
												}
							  else if($pow==+04){$result=(float)$result;
	                                             $result=$result/1000;
							                     $result = number_format($result, 4, '.', ' ');
		    	                                 $clb="Auto 100kΩ";
                                                 $unit="kΩ";
												 }
							  else if($pow==+05){$result=(float)$result;
	                                             $result=$result/1000000;
							                     $result = number_format($result, 6, '.', ' ');
												 $clb="Auto 1MΩ";
                                                 $unit="MΩ";
		    	                                 }
							  else if($pow==+06){$result=(float)$result;
												 $result=$result/1000000;
	                                             if($result<=1.2){$result = number_format($result, 6, '.', ' ');
	                                                              $clb="Auto 1MΩ";																							   
																 }
							                     else {$result = number_format($result, 5, '.', ' ');
	                                                   $clb="Auto 10MΩ";																							   
												       }
		    	                                 $unit="MΩ";
												}
							  else if($pow==+07){$result=(float)$result;
	                                             $result=$result/1000000;
							                     $result = number_format($result, 4, '.', ' ');
												 $clb="Auto 10MΩ";
												 $unit="MΩ";
		    	                                 }
																		//
							  else if($pow==-02){$result=(float)$result;
	                                             $result=$result;
							                     $result = number_format($result, 4, '.', ' ');
                                                 $clb="Auto 100Ω";
                                                 $unit="Ω";																							   
												}
                              $resultragc=$clb;
                              $resultunit=$unit;
                              $resultvol=$result; 
                             break;
                }


socket_close($socket);

$result1=(float)$result1;
$result1 = number_format($result1, 3, '.', ' ');
 // measure curr ps
 $socket2  = socket_create(AF_INET, SOCK_STREAM, SOL_TCP) or die("Could not create socket\n");
             socket_connect($socket2, $host, $port) or die("Could not connect to server\n");
               
              $vol1="INST OUT1\n MEASure:CURRent?\n";
              socket_write($socket2 , $vol1, strlen($vol1)) or die("Could not send data to server\n");
              $result3 = socket_read ($socket2 , 1024) or die("Could not read server response4\n");
     
              socket_close($socket2);
              $result3=(float)$result3;
              if($result3 <1 ){$result3=$result3*1000;
                               $result3 = number_format($result3, 1, '.', ' ');
	                           $s='mA';
						       $l=1;
						       }
              else {$result3 = number_format($result3, 3, '.', ' ');
			  $s='A';}
if($RoleDmm1==$RoleDmm2){if($FuncDmm1=="volt")
                                              echo $result1."/".$result3." ".$s."/".$sign1vol.$resultvol."/".$resultrag."/".$resultunitv;
                         else
                                              echo $result1."/".$result3." ".$s."/".$sign2curr.$resultvol."/".$resultragc."/".$resultunit;    
                        }
else{if($FuncDmm1=="volt" && $FuncDmm2=="curr") 
echo $result1."/".$result3." ".$s."/".$sign1vol.$resultvol."/".$resultrag."/".$resultunitv."/".$sign2curr2.$resultdmm2."/".$resultragc2."/".$resultunit2;
else if($FuncDmm2=="volt" && $FuncDmm1=="curr")
echo $result1."/".$result3." ".$s."/".$sign2curr.$resultvol."/".$resultragc."/".$resultunit."/".$sign1vol2.$resultdmm2."/".$resultrag2."/".$resultunitv2;  
else if($FuncDmm2=="curr" && $FuncDmm1=="curr") 
echo $result1."/".$result3." ".$s."/".$sign2curr.$resultvol."/".$resultragc."/".$resultunit."/".$sign2curr2.$resultdmm2."/".$resultragc2."/".$resultunit2;
else if($FuncDmm2=="curr" && $FuncDmm1=="reas") 
echo $result1."/".$result3." ".$s."/".$sign2curr.$resultvol."/".$resultragc."/".$resultunit."/".$sign1vol2.$resultdmm2."/".$resultragc2."/".$resultunit2;       
}
//echo $result1."/".$result3." ".$s."/".$RoleDmm2;
//$ip = $_SERVER['REMOTE_ADDR'];


$today = getdate();
//$day = $today['weekday'];
//$month = $today['month'];
//$year=$today['year'];
$hour = $today['hours'];
$minute = $today['minutes'];
$datetp=date("Y/m/d");
if($minute<10) $minute="0".$minute;
$text =$user.",".$ip.",".$datetp.",".date("H:i:s").",".$voltps.",".$sens.",".$Ltype.",".$sign1vol.$resultvol.",".$resultunitv.",".$sign2curr2.$resultdmm2.",".$resultunit2. PHP_EOL;
$filename = 'tracker.log';
$fp = fopen($filename, 'a');
fwrite($fp, $text);

fclose($fp);
?>
